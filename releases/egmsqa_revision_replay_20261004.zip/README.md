# EGMSQA revision replay

Final repository: https://github.com/WendongYao/Auditable-Hybrid-Inference-for-GIS-reasoning

This package contains the real 30-series full-prefix matched study (180 questions), the 15-series conditional noise study, saved GPT-5.2 responses, exact prompts, deterministic analyzers, scoring code and four audit cases. It is a curated addition to the existing repository. It does not reproduce every historical experiment or claim independent test performance.

## Quick start (no API key, GPU or paid calls)

Use Python 3.12.14. From the extracted package directory, in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-replay.txt
.\.venv\Scripts\python.exe replay.py --mode cases
.\.venv\Scripts\python.exe replay.py --mode all
```

On Linux/macOS replace `.\.venv\Scripts\python.exe` with `.venv/bin/python`.

`cases` verifies the manifest, regenerates evidence and prompts, reruns all four deterministic rules for the complete six-task bundles of the four illustrated points, reapplies both gate constraints to the stored LLM answers, and checks final answers. Expected case paths are 4.4 -> 2.75 -> 2.75 (B2 correction), seasonal -> nonseasonal -> nonseasonal (B1 error), none -> 5.3 -> none (C2 gate conflict), and -5.8 -> -5.8 -> -5.8 (signed negative event).

`all` also reruns deterministic analysis on all 180 questions and reanalyzes saved responses to rebuild the matched accuracy and paired-difference tables, and uncertainty overview, task sensitivity and conditional distributions. Expected matched accuracies are 47.7778%, 56.1111%, 56.1111%, 55.5556%, and 61.6667% for Raw, Evidence, Hybrid without gate, Full hybrid, and same-tool deterministic control. All checks must finish without an assertion error. Logs and `verification.json` are under `replay_output/`.

The uncertainty table replay reuses the already computed perturbed rule outputs and saved model calls; it does not repeat provider inference or regenerate all 3,780 deterministic fits. The original propagation experiment reran the affected branches. This package distinguishes replay of those results from new inference. Re-extract the archive for each clean run because analysis recreates output files and the input manifest is immutable.

## Contents and provenance

- `scripts/`: transitive local source dependencies of the replay, scorer and exact analyzers.
- `egmsqa/out_qa_v5_8/revision_20261002_matched/`: selection, 180 observations/labels, 360 frozen requests and responses, rules, predictions, audit cases and reference tables.
- `egmsqa/out_qa_v5_8/revision_20261002_uncertainty/`: 3,780 requests and responses, paired perturbations, rules, final predictions and reference tables.
- `MANIFEST.json`: SHA256 for every distributed input and source file.

Inputs are EGMS L3 Ortho Vertical 2019–2023 derived observations. Generated using European Union's Copernicus Land Monitoring Service information. Original product access: https://egms.land.copernicus.eu/ (EU Login may be required). Attribution guidance: https://land.copernicus.eu/en/faq . Original tile names and file hashes are in `raw_manifest.json`; derived dataset and prompt hashes are in the frozen manifests. No private credentials are needed for replay.

The previously published benchmark is at https://doi.org/10.5281/zenodo.20031637 . The 2026-10-02 revision bundle is a separate artifact and must not be represented as already present in that older deposit. The repository publication and clean download verification of this new bundle are pending until the prepared files are uploaded.

## Scientific interpretation

This is retrospective development evidence. Weak labels are operational analytical definitions, not independently established geophysical truth. C1 uses one acquisition-index tolerance; C2 keeps the signed jump. `none` is a task answer, not a calibrated abstention. The noise study assumes RMSE-scaled Gaussian errors, with independent or 30-day correlated draws and 20 repeats per scenario. It is conditional sensitivity, not a calibrated uncertainty interval. Two unperturbed repeats measure model variability. Missing/invalid answers remain in the evaluation denominator.

Cases one to three were selected after seeing outputs for explanatory purposes; the negative-step case follows the frozen selection order. Their frequency is not a performance estimate. Provider output cannot be guaranteed identical in a fresh paid run, even at temperature zero. No paid runner is invoked by the commands above.

## 2026-10-04 evidence/intervention extension

Run `python replay_evidence.py` after installing the same requirements. This verifies all manifest hashes, restricts the 252-question reference to a field allowlist, poisons/removes gold metadata, reproduces 504 frozen prompts, rebuilds task-wise helped/harmed counts and point-cluster bootstrap, and replays saved GPT perturbation responses through the frozen fallback. Expected reference 252/252; R/E/H0/OLD/fallback 211/224/187/192/225 correct. Expected older GPT E and fallback both 101/180. No model calls, tokens or account setup are required. Use a freshly extracted archive for each replay command because some output files are rewritten.

The Gemini development experiment and the GPT matched/sensitivity experiment have different samples and generation settings. They are not a cross-model ranking. Product RMSE is a shared input whose prefix-only provenance is not established. Operational-label agreement is not physical ground truth. The fallback policy is development-selected and invalid-to-valid recovery does not prove calibrated reliability. None remains a legal answer.

`revision_evidence_audit_20261004/` stores per-task transitions, per-example transitions, location-cluster sampling summaries, per-task sensitivity and per-source conditional distributions. No mixed-unit pooled numerical deltas are reported. `offline_round2_dev_20261004/` retains all finite candidates. Historical input-adapter outputs are marked superseded in the validity notice; repaired predictions are used here.
