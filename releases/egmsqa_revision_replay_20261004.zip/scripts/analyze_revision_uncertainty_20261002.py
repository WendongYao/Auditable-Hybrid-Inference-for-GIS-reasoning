"""Conditional sensitivity analysis with fixed labels and complete paired reruns."""
import datetime
import json
from collections import defaultdict
import numpy as np
from prepare_revision_uncertainty_20261002 import OUT, MATCHED
from revision_window_audit_20261002 import records
from revision_matched_protocol_20261002 import compose
from analyze_revision_matched_20261002 import load_api,pred
import revise_results_20261001 as a
import score

def kind(p,task):
    if p.get('parse_error') or p.get('answer_parsed') is None:return 'invalid'
    v=p['answer_parsed']
    if v=='none':return 'none'
    if task.startswith('A1') or task.startswith('B1'):return str(v)
    if task.startswith('C1'):return 'date'
    try:
        f=float(v)
        return 'negative' if f<0 else 'positive' if f>0 else 'zero'
    except Exception:return 'invalid'

def numeric(v,task):
    if v is None or v=='none':return None
    try:
        if task=='C1_step_time':return float(datetime.datetime.strptime(str(v),'%Y%m%d').toordinal())
        if task in ['A2_trend_v','B2_seasonality_amp','C2_step_mag']:return float(v)
    except Exception:pass
    return None

def main():
    gold={x['id']:x for x in records(MATCHED/'dataset_fullprefix.jsonl')}
    data={x['id']:x for x in records(OUT/'dataset.jsonl')}
    calls=load_api(OUT/'api',OUT/'requests_frozen.jsonl')
    evidence={r['id']:pred(r) for r in calls.values()}
    rules,full=compose(evidence,OUT/'rules')
    db=a.load(OUT/'rules/baseline.jsonl',True);dr,df=compose(db,OUT/'rules')
    systems={'Evidence_LLM':evidence,'Hybrid_no_gate':rules,'Hybrid_full':full,'Deterministic_no_gate':dr,'Deterministic_full':df}
    controls={name:a.load(MATCHED/f'preds/{name}.jsonl',True) for name in ['Evidence_LLM','Hybrid_no_gate','Hybrid_full','Deterministic_full']}
    controls['Deterministic_no_gate']=a.load(MATCHED/'deterministic_rules.jsonl',True)
    rows=[]; distributions=[];metrics=[]
    for name,ps in systems.items():
        assert set(ps)==set(data)
        a.jsonlwrite(OUT/f'preds/{name}.jsonl',ps.values())
        groups=defaultdict(list)
        for i,x in data.items():
            original=gold[x['source_id']];p=ps[i];control=controls[name][x['source_id']];task=x['task_name']
            ok,reason=score.score_one(original,p)
            v=numeric(p['answer_parsed'],task);c=numeric(control['answer_parsed'],task)
            r={'system':name,'id':i,'source_id':x['source_id'],'tile':x['tile_id'],'pid':x['pid'],'task':task,
               'scenario':x['scenario'],'replicate':x['replicate'],'answer':p['answer_parsed'],'control_answer':control['answer_parsed'],
               'kind':kind(p,task),'control_kind':kind(control,task),'kind_changed':int(kind(p,task)!=kind(control,task)),
               'answer_changed':int(p['answer_parsed']!=control['answer_parsed']),'none':int(p['answer_parsed']=='none'),
               'invalid':int(kind(p,task)=='invalid'),'correct':int(ok),'reason':reason,
               'numeric_value':v,'numeric_delta_from_control':None if v is None or c is None else v-c,
               'date_index_delta_from_control':None,'date_outside_grid':None}
            if task=='C1_step_time' and v is not None:
                grid=np.array([datetime.date.fromisoformat(d).toordinal() for d in original['context']['series']['t_iso']])
                if c is not None:r['date_index_delta_from_control']=int(np.argmin(abs(grid-v))-np.argmin(abs(grid-c)))
                r['date_outside_grid']=int(v<grid[0] or v>grid[-1])
            rows.append(r);groups[(x['scenario'],task,x['source_id'])].append(r)
        for (scenario,task,source),rr in groups.items():
            vals=[r['numeric_value'] for r in rr if r['numeric_value'] is not None and not r['invalid']]
            delta=[r['numeric_delta_from_control'] for r in rr if r['numeric_delta_from_control'] is not None and not r['invalid']]
            distributions.append({'system':name,'scenario':scenario,'task':task,'source_id':source,'n':len(rr),'valid_numeric_n':len(vals),
                'none_rate':np.mean([r['none'] for r in rr]),'invalid_rate':np.mean([r['invalid'] for r in rr]),
                'kind_flip_rate':np.mean([r['kind_changed'] for r in rr]),'answer_change_rate':np.mean([r['answer_changed'] for r in rr]),
                'accuracy':np.mean([r['correct'] for r in rr]),'mean':np.mean(vals) if vals else None,'std':np.std(vals,ddof=1) if len(vals)>1 else None,
                'q025':np.quantile(vals,.025) if vals else None,'q975':np.quantile(vals,.975) if vals else None,
                'median_absolute_delta':np.median(np.abs(delta)) if delta else None,'numeric_unit':{'C1_step_time':'date_ordinal_days','A2_trend_v':'mm/year','B2_seasonality_amp':'mm','C2_step_mag':'mm'}.get(task,'categorical'),
                'distribution_scope':'conditional on valid non-none numeric/date output; 20 replicates, not calibrated interval'})
    a.csvwrite(OUT/'per_example.csv',rows);a.csvwrite(OUT/'conditional_distributions.csv',distributions)
    groups=defaultdict(list)
    for r in rows:groups[(r['system'],r['scenario'],r['task'])].append(r)
    for (system,scenario,task),rr in groups.items():
        vals=[abs(r['numeric_delta_from_control']) for r in rr if r['numeric_delta_from_control'] is not None and not r['invalid']]
        metrics.append({'system':system,'scenario':scenario,'task':task,'n':len(rr),'series_n':len({r['source_id'] for r in rr}),
            'accuracy':np.mean([r['correct'] for r in rr]),'kind_flip_rate':np.mean([r['kind_changed'] for r in rr]),
            'answer_change_rate':np.mean([r['answer_changed'] for r in rr]),'none_rate':np.mean([r['none'] for r in rr]),
            'invalid_rate':np.mean([r['invalid'] for r in rr]),'median_absolute_numeric_delta':np.median(vals) if vals else None,
            'numeric_comparable_n':len(vals)})
    source_ids=sorted({x['source_id'] for x in data.values()})
    for name in systems:
        for task in a.TASKS:
            selected=[i for i in source_ids if gold[i]['task_name']==task]
            ps=[controls[name][i] for i in selected]
            numeric_n=sum(numeric(p['answer_parsed'],task) is not None for p in ps)
            metrics.append({'system':name,'scenario':'original_control','task':task,'n':len(ps),'series_n':len(ps),
                'accuracy':np.mean([score.score_one(gold[i],controls[name][i])[0] for i in selected]),
                'kind_flip_rate':0.,'answer_change_rate':0.,'none_rate':np.mean([p['answer_parsed']=='none' for p in ps]),
                'invalid_rate':np.mean([kind(p,task)=='invalid' for p in ps]),'median_absolute_numeric_delta':0. if numeric_n else None,
                'numeric_comparable_n':numeric_n})
    a.csvwrite(OUT/'task_sensitivity.csv',metrics)
    overview=[]
    for name in systems:
        initial=[r for r in metrics if r['system']==name and r['scenario']=='original_control']
        overview.append({'system':name,'scenario':'original_control','n':len(source_ids),
            **{k:np.mean([r[k] for r in initial]) for k in ['accuracy','answer_change_rate','kind_flip_rate','none_rate','invalid_rate']}})
        for scenario in ['unperturbed_repeat','iid_rmse','correlated_rmse_30d']:
            rr=[r for r in rows if r['system']==name and r['scenario']==scenario]
            overview.append({'system':name,'scenario':scenario,'n':len(rr),'accuracy':np.mean([r['correct'] for r in rr]),
                'answer_change_rate':np.mean([r['answer_changed'] for r in rr]),'kind_flip_rate':np.mean([r['kind_changed'] for r in rr]),
                'none_rate':np.mean([r['none'] for r in rr]),'invalid_rate':np.mean([r['invalid'] for r in rr])})
    a.csvwrite(OUT/'overview.csv',overview)
    summary={'requests':len(calls),'series_n':15,'replicates_per_noise_scenario':20,'cost_usd':sum(r['cost_usd'] for r in calls.values()),
             'invalid_LLM_responses':sum(bool(r.get('parse_error')) for r in calls.values()),'overview':overview,
             'limitation':'Conditional RMSE-scaled noise sensitivity; not calibrated observational uncertainty. Fixed historical weak labels.'}
    a.dump(OUT/'results_summary.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
