#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Score EGMS-QA predictions against a dataset jsonl.

修复点（核心）：
- pred 文件里常见混入“非 JSON 行”、BOM、NUL(\x00)、UTF-16 等导致 json.loads 在 column 1 直接炸
- 现在 read_jsonl() 会：
  1) 自动检测 BOM（utf-8-sig / utf-16-le / utf-16-be）
  2) 清理 NUL、BOM、空行
  3) 默认跳过明显不是 JSON 的行（不以 '{' 或 '[' 开头）
  4) 默认跳过 JSON 解析失败的坏行，并统计/打印（可用 --strict_jsonl 改成遇到坏行直接报错）

Usage:
  python scripts/score2.py --dataset dev_balanced.jsonl --pred preds.jsonl \
    --out_dir out/scores/run1 --mode intersection --print_outputs

Tip:
  如果你想强制定位坏行，用 --strict_jsonl，会在报错里带行号和 head 内容。
"""
from __future__ import annotations

import argparse
import json
import math
import re
from datetime import datetime, date
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

import pandas as pd

KNOWN_METRICS = {
    "class_exact",
    "num_within_tol",
    "num_or_none_within_tol",
    "time_or_none_within_k",
}

_METRIC_ALIAS = {
    "cls_exact": "class_exact",
    "class": "class_exact",
    "categorical_exact": "class_exact",
    "num_tol": "num_within_tol",
    "numeric_within_tol": "num_within_tol",
    "num_or_none_tol": "num_or_none_within_tol",
    "time_or_none_k": "time_or_none_within_k",
}


# -------------------------
# Robust JSONL reader
# -------------------------
def _detect_text_encoding(path: str) -> str:
    """
    基于 BOM 做一个轻量检测：
      - UTF-8 BOM:   EF BB BF -> 'utf-8-sig'
      - UTF-16 LE:   FF FE    -> 'utf-16-le'
      - UTF-16 BE:   FE FF    -> 'utf-16-be'
    其他默认按 'utf-8' 读（并且 errors='replace'）。
    """
    p = Path(path)
    with p.open("rb") as f:
        b = f.read(4)
    if b.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig"
    if b.startswith(b"\xff\xfe"):
        return "utf-16-le"
    if b.startswith(b"\xfe\xff"):
        return "utf-16-be"
    return "utf-8"


def read_jsonl(
    path: str,
    *,
    strict: bool = False,
    skip_non_json_prefix: bool = True,
    verbose: bool = True,
) -> Iterable[Dict[str, Any]]:
    """
    读取 JSONL（每行一个 JSON object），对真实环境更鲁棒：
    - 自动识别 BOM / utf-16
    - 清理 NUL (\x00) / BOM
    - 默认跳过非 JSON 行 & 坏行（并统计）
    - strict=True 时遇到坏行直接 raise，方便定位

    注意：默认 skip_non_json_prefix=True，会跳过不以 '{'/'[' 开头的行（常见日志/进度输出）。
    """
    encoding = _detect_text_encoding(path)
    bad_json = 0
    skipped_prefix = 0
    empty = 0

    with open(path, "r", encoding=encoding, errors="replace") as f:
        for ln, line in enumerate(f, 1):
            # 清理常见隐形字符
            if "\x00" in line:
                line = line.replace("\x00", "")
            line = line.lstrip("\ufeff")  # 兼容少数情况下 BOM 没被 encoding 吃掉
            s = line.strip()

            if not s:
                empty += 1
                continue

            if skip_non_json_prefix and s[0] not in "{[":
                skipped_prefix += 1
                continue

            try:
                obj = json.loads(s)
                yield obj
            except json.JSONDecodeError as e:
                bad_json += 1
                if strict:
                    raise ValueError(
                        f"Bad json at {path}:{ln}: {e}. head={s[:160]!r}"
                    ) from e
                # 非 strict：跳过坏行
                continue

    # 打印统计（只打印一次，所以放在函数尾部不合适 —— 但 generator 会延迟执行）
    # 因为 generator 结束时才会走到这里，所以我们用一个小技巧：把统计打印放到 finally。
    # 为保持实现简单，我们不在这里打印，改在调用方里通过 wrapper 实现统计打印。
    # 但为了用户“直接可用”，我们做一个折中：当 verbose=True 且不是 strict，打印到 stderr/print。
    if verbose and (bad_json or skipped_prefix) and not strict:
        # 注意：这里打印需要在迭代完全结束后才会触发
        print(
            f"[read_jsonl] path={path} encoding={encoding} "
            f"skipped_prefix={skipped_prefix} bad_json={bad_json} empty={empty}"
        )


def norm_str(x: Any) -> str:
    if x is None:
        return ""
    return str(x).strip().lower()


def try_float(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x)):
        return float(x)
    s = str(x).strip()
    if s == "":
        return None
    if s.lower() in {"none", "null", "nan"}:
        return None
    try:
        return float(s)
    except Exception:
        return None


def parse_yyyymmdd(x: Any) -> Optional[date]:
    if x is None:
        return None
    s = str(x).strip()
    if s.lower() in {"none", "null", ""}:
        return None
    try:
        if "-" in s:
            return datetime.strptime(s[:10], "%Y-%m-%d").date()
        s2 = re.sub(r"[^0-9]", "", s)
        if len(s2) >= 8:
            return datetime.strptime(s2[:8], "%Y%m%d").date()
    except Exception:
        return None
    return None


def median_cadence_days(gold_ex: Dict[str, Any], fallback: float = 6.0) -> float:
    series = (gold_ex.get("series") or {}).get("points") or (gold_ex.get("series") or {}).get("series")
    if not series:
        return fallback
    dates = []
    for p in series:
        t = p.get("t") or p.get("t_iso") or p.get("date")
        d = parse_yyyymmdd(t)
        if d is not None:
            dates.append(d)
    dates = sorted(set(dates))
    if len(dates) < 3:
        return fallback
    diffs = [(dates[i + 1] - dates[i]).days for i in range(len(dates) - 1)]
    diffs = [d for d in diffs if d > 0]
    if not diffs:
        return fallback
    diffs.sort()
    return float(diffs[len(diffs) // 2])


def _extract_params_from_metric(metric_raw: str, eval_obj: Dict[str, Any]) -> None:
    s = metric_raw

    # abs_tol
    if "abs_tol" not in eval_obj:
        m = re.search(r"abs_tol\s*=\s*([0-9]*\.?[0-9]+)", s)
        if m:
            eval_obj["abs_tol"] = float(m.group(1))
    if "abs_tol" not in eval_obj:
        m = re.search(r"num(?:_or_none)?_within_tol\s*:\s*([0-9]*\.?[0-9]+)", s)
        if m:
            eval_obj["abs_tol"] = float(m.group(1))

    # k
    if "k" not in eval_obj:
        m = re.search(r"\bk\s*=\s*([0-9]+)\b", s)
        if m:
            eval_obj["k"] = int(m.group(1))
    if "k" not in eval_obj:
        m = re.search(r"tol\s*=\s*k\s*[:=]\s*([0-9]+)", s)
        if m:
            eval_obj["k"] = int(m.group(1))


def normalize_metric(eval_obj: Dict[str, Any]) -> str:
    raw = eval_obj.get("metric")
    s = "" if raw is None else str(raw).strip()
    if s == "":
        return ""

    # Strip suffix: "(...)" or ":..." or "[...]"
    base = re.split(r"[\(\[:]", s, maxsplit=1)[0].strip()
    base = base.split(":", 1)[0].strip()
    base = _METRIC_ALIAS.get(base, base)

    if base != s:
        _extract_params_from_metric(s, eval_obj)

    eval_obj["metric"] = base
    return base


def _bucket_label(ex: Dict[str, Any]) -> str:
    if ex.get("bucket_label") is not None:
        return str(ex["bucket_label"])
    b = ex.get("bucket") or {}
    if isinstance(b, dict) and b.get("label") is not None:
        return str(b.get("label"))
    return ""


def score_one(gold_ex: Dict[str, Any], pred_ex: Optional[Dict[str, Any]]) -> Tuple[bool, str]:
    eval_obj = gold_ex.get("eval") or {}
    metric = normalize_metric(eval_obj)

    # pred answer
    pred_ans = None
    if pred_ex is not None:
        pred_ans = pred_ex.get("answer_parsed", None)
        if pred_ans is None:
            pred_ans = pred_ex.get("answer_numeric", None)
        if pred_ans is None:
            pred_ans = pred_ex.get("answer", None)

    # gold answer
    gold_ans = gold_ex.get("answer", None)
    if gold_ans is None:
        gold_ans = gold_ex.get("gold", None)

    if pred_ex is None:
        return False, "missing_pred"
    if pred_ans is None or (isinstance(pred_ans, str) and pred_ans.strip() == ""):
        return False, "format_fail:empty_pred_answer"

    if metric == "class_exact":
        ok = norm_str(pred_ans) == norm_str(gold_ans)
        return ok, "ok" if ok else "mismatch"

    if metric == "num_within_tol":
        g = try_float(gold_ex.get("answer_numeric", gold_ans))
        p = try_float(pred_ans)
        if g is None or p is None:
            return False, "num_parse_fail"
        abs_tol = float(eval_obj.get("abs_tol", 0.5))
        ok = abs(p - g) <= abs_tol
        return ok, "ok" if ok else f"num_outside_tol(abs_tol={abs_tol})"

    if metric == "num_or_none_within_tol":
        gold_none = (gold_ex.get("answer_numeric") is None) or (norm_str(gold_ans) == "none")
        pred_none = norm_str(pred_ans) == "none" or try_float(pred_ans) is None

        if gold_none:
            ok = pred_none
            return ok, "ok" if ok else "expected_none"
        g = try_float(gold_ex.get("answer_numeric", gold_ans))
        p = try_float(pred_ans)
        if g is None or p is None:
            return False, "num_parse_fail"
        abs_tol = float(eval_obj.get("abs_tol", 0.5))
        ok = abs(p - g) <= abs_tol
        return ok, "ok" if ok else f"num_outside_tol(abs_tol={abs_tol})"

    if metric == "time_or_none_within_k":
        gold_none = norm_str(gold_ans) == "none"
        pred_none = norm_str(pred_ans) == "none"
        if gold_none:
            ok = pred_none
            return ok, "ok" if ok else "expected_none"

        gd = parse_yyyymmdd(gold_ans)
        pd_ = parse_yyyymmdd(pred_ans)
        if gd is None or pd_ is None:
            return False, "time_parse_fail"

        tol = eval_obj.get("tol") or {}
        k = tol.get("value", None)
        if k is None:
            k = eval_obj.get("k", 1)
        k = int(k)

        cadence = median_cadence_days(gold_ex, fallback=6.0)
        day_tol = max(1.0, cadence) * float(k)
        ok = abs((pd_ - gd).days) <= day_tol
        return ok, "ok" if ok else f"time_outside_tol(days_tol={day_tol:.1f})"

    if metric in {"", None}:
        return False, "missing_metric"

    return False, f"unknown_metric:{metric}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--pred", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--mode", default="intersection", choices=["intersection", "union"])
    ap.add_argument("--print_outputs", action="store_true")
    ap.add_argument("--print_output", action="store_true")  # alias

    # 新增：更鲁棒控制
    ap.add_argument("--strict_jsonl", action="store_true", help="遇到坏行直接报错（含行号），用于定位问题")
    ap.add_argument(
        "--keep_non_json_prefix_lines",
        action="store_true",
        help="不跳过非 JSON 前缀行（默认会跳过不以 '{'/'[' 开头的行）",
    )
    ap.add_argument("--quiet_read", action="store_true", help="不打印 read_jsonl 的跳过统计")

    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    gold_by_id: Dict[str, Dict[str, Any]] = {}
    for ex in read_jsonl(
        args.dataset,
        strict=args.strict_jsonl,
        skip_non_json_prefix=not args.keep_non_json_prefix_lines,
        verbose=not args.quiet_read,
    ):
        if ex.get("id"):
            gold_by_id[ex["id"]] = ex

    pred_by_id: Dict[str, Dict[str, Any]] = {}
    for ex in read_jsonl(
        args.pred,
        strict=args.strict_jsonl,
        skip_non_json_prefix=not args.keep_non_json_prefix_lines,
        verbose=not args.quiet_read,
    ):
        if ex.get("id"):
            pred_by_id[ex["id"]] = ex

    if args.mode == "intersection":
        ids = sorted(set(gold_by_id) & set(pred_by_id))
    else:
        ids = sorted(set(gold_by_id) | set(pred_by_id))

    rows = []
    unknown_metrics: Dict[str, int] = {}

    for _id in ids:
        g = gold_by_id.get(_id)
        if g is None:
            continue
        p = pred_by_id.get(_id)
        ok, note = score_one(g, p)

        task = g.get("task_name", "")
        if note.startswith("unknown_metric:"):
            unknown_metrics[task] = unknown_metrics.get(task, 0) + 1

        rows.append(
            {
                "id": _id,
                "task_name": task,
                "bucket_label": _bucket_label(g),
                "gold_answer": g.get("answer", g.get("gold")),
                "pred_answer": None
                if p is None
                else p.get("answer_parsed", p.get("answer_numeric", p.get("answer"))),
                "ok": int(bool(ok)),
                "note": note,
                "metric_raw": (g.get("eval") or {}).get("metric"),
            }
        )

    df = pd.DataFrame(rows)
    (out_dir / "per_example.csv").write_text(df.to_csv(index=False), encoding="utf-8")

    if len(df) == 0:
        summary = {
            "mode": args.mode,
            "coverage_pred_over_gold": 0.0,
            "micro_acc": 0.0,
            "macro_acc_over_tasks": 0.0,
            "n_gold": len(gold_by_id),
            "n_pred": len(pred_by_id),
            "n_scored": 0,
            "n_tasks": 0,
            "unknown_metric_by_task": unknown_metrics,
        }
        (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print("Saved:", str(out_dir))
        print("Summary:", summary)
        return

    coverage = (
        (len(ids) / max(1, len(gold_by_id)))
        if args.mode == "intersection"
        else (len(pred_by_id) / max(1, len(gold_by_id)))
    )
    micro_acc = float(df["ok"].mean())

    by_task = (
        df.groupby("task_name")
        .agg(
            n=("id", "count"),
            acc=("ok", "mean"),
            format_fail=("note", lambda s: float(sum(str(x).startswith("format_fail") for x in s)) / max(1, len(s))),
        )
        .reset_index()
        .sort_values(["task_name"])
    )
    by_task.to_csv(out_dir / "by_task.csv", index=False)

    by_task_bucket = (
        df.groupby(["task_name", "bucket_label"])
        .agg(n=("id", "count"), acc=("ok", "mean"))
        .reset_index()
        .sort_values(["task_name", "bucket_label"])
    )
    by_task_bucket.to_csv(out_dir / "by_task_bucket.csv", index=False)

    macro_acc = float(by_task["acc"].mean()) if len(by_task) else 0.0

    summary = {
        "mode": args.mode,
        "coverage_pred_over_gold": float(coverage),
        "micro_acc": micro_acc,
        "macro_acc_over_tasks": macro_acc,
        "n_gold": int(len(gold_by_id)),
        "n_pred": int(len(pred_by_id)),
        "n_scored": int(len(df)),
        "n_tasks": int(by_task["task_name"].nunique()),
        "unknown_metric_by_task": unknown_metrics,
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("Saved:", str(out_dir))
    print(
        "Summary:",
        {k: summary[k] for k in ["mode", "coverage_pred_over_gold", "micro_acc", "macro_acc_over_tasks", "n_gold", "n_pred", "n_scored", "n_tasks"]},
    )
    if unknown_metrics:
        print("[WARN] unknown metrics encountered (counts by task):", unknown_metrics)

    if args.print_outputs or args.print_output:
        print("\n==================== by_task.csv (path=%s) ====================" % (out_dir / "by_task.csv"))
        print(by_task.to_string(index=False))
        print("\n==================== by_task_bucket.csv (path=%s) ====================" % (out_dir / "by_task_bucket.csv"))
        print(by_task_bucket.to_string(index=False))
        print("\n==================== summary.json (path=%s) ====================" % (out_dir / "summary.json"))
        print((out_dir / "summary.json").read_text(encoding="utf-8").rstrip("\n"))


if __name__ == "__main__":
    main()
