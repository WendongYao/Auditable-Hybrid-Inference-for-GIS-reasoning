"""Outcome-blind selection and raw-prefix reconstruction for fresh paired experiments."""
import copy
import hashlib
import json
import re
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np
import pandas as pd
from revision_window_audit_20261002 import DATA, ROOT, records, fingerprint
from egms_autolabel_trend_qa_v5_8 import parse_date_cols_from_df_columns, build_examples_for_pid
from render_prompt_routeA_a3 import render_prompt_routeA_a3
import revise_results_20261001 as a

OUT=DATA/'revision_20261002_matched'
SEED=20261002

def rank(k):return hashlib.sha256(f'{SEED}|{k[0]}|{k[1]}'.encode()).hexdigest()

def main():
    OUT.mkdir(exist_ok=True)
    source=DATA/'analysis_20260504/natural_subset_50k/natural_subset.jsonl'
    groups=defaultdict(dict)
    for x in records(source):groups[(x['tile_id'],x['pid'])][x['task_name']]=x
    strata=defaultdict(list)
    for k,bundle in groups.items():
        if set(bundle)!=set(a.TASKS):continue
        ans=bundle['C2_step_mag']['answer']
        sign='none' if str(ans)=='none' else ('negative' if float(ans)<0 else 'positive')
        strata[(k[0],sign)].append(k)
    selected=[]; inventory=[]
    for (tile,sign), keys in sorted(strata.items()):
        chosen=sorted(keys,key=rank)[:2]
        selected.extend(chosen)
        inventory.append({'tile':tile,'sign':sign,'available_series':len(keys),'selected_series':len(chosen)})
    assert len(selected)==len(set(selected))
    # Freeze IDs before reading any predictions. No outcome-based replacement.
    a.dump(OUT/'selection.json',{'seed':SEED,'policy':'two SHA256-ranked complete series per available tile x C2-sign cell',
        'source':str(source),'source_sha256':a.sha(source),'strata':inventory,'selected':[list(k) for k in selected],
        'scope':'retrospective stratified mechanistic subset; not independent test or prevalence estimate'})
    bytile=defaultdict(set)
    for tile,pid in selected:bytile[tile].add(pid)
    rebuilt={}; raw_manifest=[]
    for path in sorted((ROOT/'data/raw').glob('EGMS_L3_*.csv')):
        tile=re.search(r'E\d+N\d+',path.name).group()
        if tile not in bytile:continue
        dates=parse_date_cols_from_df_columns(list(pd.read_csv(path,nrows=0).columns)); train=int(.8*len(dates))
        for chunk in pd.read_csv(path,chunksize=10000,dtype={'pid':str}):
            sub=chunk.loc[chunk.pid.isin(bytile[tile])]
            for _,row in sub.iterrows():
                k=(tile,str(row['pid'])); bundle=groups[k]; ref=bundle['A1_trend_dir']
                exs=build_examples_for_pid(tile_id=tile,pid=k[1],coord=ref['coord'],static_ctx=copy.deepcopy(ref['context']['static']),
                    meta_ctx_base={'window':'train_only'},date_cols=dates,y_full=row[dates].to_numpy(dtype=float),
                    train_epochs=train,prompt_points=train,series_mode='last_n',step_series_mode='last_n')
                for x in exs:
                    old=bundle[x['task_name']]
                    assert x['answer']==old['answer'],('label reconstruction mismatch',x['id'],x['answer'],old['answer'])
                    x['revision_input_policy']='full_training_prefix_without_label_conditioned_cropping'
                    rebuilt[x['id']]=x
            if all(f'{tile}_{pid}_A1_trend_dir' in rebuilt for pid in bytile[tile]):break
        raw_manifest.append({'path':str(path),'sha256':a.sha(path),'train_epochs':train})
        print('Rebuilt',tile,flush=True)
    assert len(rebuilt)==len(selected)*6
    dataset=[rebuilt[f'{tile}_{pid}_{t}'] for tile,pid in selected for t in a.TASKS]
    for tile,pid in selected:
        assert len({fingerprint(rebuilt[f'{tile}_{pid}_{t}']['context']['series']) for t in a.TASKS})==1
    a.jsonlwrite(OUT/'dataset_fullprefix.jsonl',dataset)
    a.dump(OUT/'raw_manifest.json',raw_manifest)
    prompts=[]
    for x in dataset:
        s=x['context']['series']; n=len(s['t_iso'])
        # Full table ensures LLM and deterministic systems have the same underlying observations.
        prompt=render_prompt_routeA_a3(x,global_mode='last_n',last_n=n,c2_semantics='signed_delta')
        prompts.append({'id':x['id'],'task_name':x['task_name'],'prompt':prompt,'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),
                        'input_series_sha256':fingerprint(s),'status':'draft_pending_semantics_check'})
    a.jsonlwrite(OUT/'draft_evidence_prompts.jsonl',prompts)
    summary={'series':len(selected),'qa':len(dataset),'labels_reproduced':len(dataset),
             'same_input_across_six_tasks':True,'api_calls':0,'prompt_status':'draft; persistence-vs-jump semantics must be resolved before API launch',
             'prompt_characters':{'min':min(len(x['prompt']) for x in prompts),'max':max(len(x['prompt']) for x in prompts),'mean':sum(len(x['prompt']) for x in prompts)/len(prompts)}}
    a.dump(OUT/'preparation_summary.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
