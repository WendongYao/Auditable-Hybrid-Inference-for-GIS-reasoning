"""Frozen retrospective controls; no network, no threshold search."""
import copy,json,datetime
from pathlib import Path
import numpy as np
import revise_results_20261001 as a
import analyze_gate_20261003 as g
import bounded_exploration_metrics_20261004 as m
import bounded_exploration_round1_20261004 as b
import bounded_exploration_round2_20261005 as r

OUT=a.DATA/'simple_controls_20261005'
PLAN=a.ROOT.parent/'revision/25_simple_control_protocol_20261005.md'

def policies(inp,e,h):
    f=copy.deepcopy(e)
    for i,p in f.items():
        if not b.valid(p) and p['task_name'].startswith(('B','C')) and b.valid(h[i]): f[i]=copy.deepcopy(h[i])
    ps={'E':copy.deepcopy(e),'F':f,'BF':r.propose(inp,e,h)[0]['B_F']}
    ref=g.operational_reference(inp.values())
    for name in ['Q_CHECK_F','Q_ALWAYS_F','H_ALWAYS_F','B2_REFERENCE_F']:ps[name]=copy.deepcopy(f)
    ps['FULL_REFERENCE']=ref
    for i,x in inp.items():
        if x['task_name']!='B2_seasonality_amp':continue
        ps['B2_REFERENCE_F'][i]=copy.deepcopy(ref[i])
        ev=a.val(e[i]);hv=a.val(h[i]);q=r.amplitude(x)
        if b.valid(e[i]) and b.finite(ev) and ev>=0:
            if q is not None and q>=.5:
                ps['Q_ALWAYS_F'][i].update(answer_parsed=round(q,1),parse_error=None)
                if abs(ev-q)>.5+1e-9:ps['Q_CHECK_F'][i].update(answer_parsed=round(q,1),parse_error=None)
            if b.valid(h[i]) and b.finite(hv) and hv>=0:ps['H_ALWAYS_F'][i]=copy.deepcopy(h[i])
    return ps

def main():
    assert not OUT.exists(),'Preserve completed comparison'
    OUT.mkdir()
    a.dump(OUT/'freeze.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':a.sha(PLAN),'script_sha256':a.sha(Path(__file__)),'retrospective':True,'new_api_calls':0})
    sets,manifest=m.load_sets()
    for group,folder in [('prospective360','prospective_frozen_bf_v2_20261005'),('cached504','frozen_validation_20261005')]:
        p=a.DATA/folder
        data=p/'dataset_fullprefix.jsonl'
        if not data.exists():
            # Original saved validation dataset; frozen_validation stores replays only.
            data=a.DATA/'revision_gate_20261003/validation/dataset_fullprefix.jsonl'
        paths=[data,p/'predictions_E.jsonl',p/'predictions_H0.jsonl']
        sets[group]=tuple(a.load(z) for z in paths)
        manifest.extend({'path':str(z),'sha256':a.sha(z)} for z in paths)
    rows=[];examples=[];checks=[];cis=[]
    for group,(ds,ee,hh) in sets.items():
        e={i:b.simple(p) for i,p in ee.items()};h={i:b.simple(p) for i,p in hh.items()}
        assert set(ds)==set(e)==set(h)
        inp=m.observable_inputs(ds);ps=policies(inp,e,h)
        poisoned=copy.deepcopy(ds)
        for x in poisoned.values():x.update(answer='POISON',answer_numeric=-999999,eval={'x':1},bucket_label='POISON',meta={})
        assert policies(m.observable_inputs(poisoned),e,h)==ps
        checks.append({'group':group,'n':len(ds),'gold_poison_invariant':True})
        original=sets['gpt180'][0] if group=='gpt_noise' else None
        for base in ['E','BF']:
            tb,ex=m.evaluate(ds,ps[base],ps,group,original)
            rows.extend({**z,'baseline':base} for z in tb)
            examples.extend({**z,'baseline':base} for z in ex)
        folder=OUT/group;folder.mkdir()
        for name,p in ps.items():a.jsonlwrite(folder/f'{name}.jsonl',p.values())
        if group=='prospective360':
            for name in ps:
                if name in ['E','F','BF']:continue
                rng=np.random.default_rng(20261005);draws=np.zeros(10000)
                for tile in sorted({x['tile_id'] for x in ds.values()}):
                    locs=sorted({g.base_id(x) for x in ds.values() if x['tile_id']==tile})
                    delta=np.array([sum(int(g.correct(x,ps['BF'][i]))-int(g.correct(x,ps[name][i])) for i,x in ds.items() if g.base_id(x)==loc) for loc in locs])
                    draws+=delta[rng.integers(0,len(locs),size=(10000,len(locs)))].sum(axis=1)
                lo,hi=np.quantile(draws/360*100,[.025,.975])
                cis.append({'comparison':'BF minus '+name,'lower_pp':float(lo),'upper_pp':float(hi),'unit':'location within fixed tile'})
    a.csvwrite(OUT/'metrics.csv',rows);a.csvwrite(OUT/'paired_changes.csv',examples)
    a.csvwrite(OUT/'verification.csv',checks);a.csvwrite(OUT/'bootstrap.csv',cis)
    a.dump(OUT/'manifest.json',manifest)
    for z in rows:
        if z['task']=='ALL' and z['baseline']=='E':print(z['group'],z['scenario'],z['candidate'],z['after_correct'],z['helped'],z['harmed'],z['changed'])

if __name__=='__main__':main()
