"""Read-only audit of label support, pairing and saved baseline input provenance."""
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'egmsqa/out_qa_v5_8'
OUT = DATA / 'revision_20261002_validity'

def records(path):
    with path.open(encoding='utf-8') as f:
        for line in f:
            if line.strip():
                yield json.loads(line)

def key(x):
    return str(x['tile_id']), str(x['pid'])

def fingerprint(series):
    return hashlib.sha256(json.dumps(series, sort_keys=True).encode()).hexdigest()

def visibility(date, dates):
    if date is None or str(date).strip() == '': return 'unknown_event_date'
    if str(date).lower() == 'none': return 'no_event_label'
    d = str(date).replace('-', '')
    grid = [t.replace('-', '') for t in dates]
    if not grid or grid != sorted(set(grid)): return 'invalid_grid'
    if d in grid: return 'exact_visible'
    if d < grid[0]: return 'before_window'
    if d > grid[-1]: return 'after_window'
    return 'inside_range_not_observed'

def save(name, rows):
    if not rows: return
    cols = list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)

def main():
    OUT.mkdir(exist_ok=True)
    paths = [DATA/'jsonl/dev_balanced.jsonl', DATA/'analysis_20260505/step_view_sensitivity/uniform_lastn_step_subset.jsonl',
             DATA/'analysis_20260505/c1c2_independent_step_subset/alternative_step_confident_rows.csv']
    gold = {x['id']: x for x in records(paths[0])}
    uniform = {x['id']: x for x in records(paths[1])}
    wanted = {key(x) for x in gold.values()}
    c1 = {}; natural_path = DATA/'jsonl/dev.jsonl'
    # Recover dates for C2 even when balanced sampling omitted its paired C1.
    for x in records(natural_path):
        if x['task_name'] == 'C1_step_time' and key(x) in wanted: c1[key(x)] = x['answer']
    print('Recovered C1 dates:', len(c1), flush=True)
    rows = []; bundles = defaultdict(list)
    for x in gold.values(): bundles[key(x)].append(x)
    for view, dataset in [('released',gold),('uniform_last64',uniform)]:
        for i,x in dataset.items():
            s=x['context']['series']; dates=s['t_iso']; task=x['task_name']
            r={'view':view,'id':i,'tile_id':x['tile_id'],'pid':x['pid'],'task':task,
               'gold':x['answer'],'mode':x['context']['meta'].get('series_mode'),
               'n_visible':len(dates),'n_train':x['meta'].get('n_obs_train'),
               'start':dates[0],'end':dates[-1],'series_sha256':fingerprint(s),
               'truncated_support':len(dates)<x['meta'].get('n_obs_train',len(dates))}
            if task.startswith('C'):
                event=c1.get(key(x)); r['event_date']=event
                r['visibility']=visibility(event,dates)
                if event and event!='none' and r['visibility']=='exact_visible':
                    idx=[t.replace('-','') for t in dates].index(event.replace('-',''))
                    r['n_before_event']=idx; r['n_from_event']=len(dates)-idx
                    r['left_observation_available']=idx>0 and s['d_mm'][idx-1] is not None and s['d_mm'][idx] is not None
                    if idx>0 and task=='C2_step_mag' and str(x['answer'])!='none':
                        delta=s['d_mm'][idx]-s['d_mm'][idx-1]
                        r['visible_adjacent_delta']=delta
                        r['gold_matches_adjacent_round1']=round(delta,1)==float(x['answer'])
            rows.append(r)
    save('window_examples.csv',rows)
    counts=Counter((r['view'],r['task'],r.get('visibility','not_event_task'),r['mode'],r['truncated_support']) for r in rows)
    save('window_summary.csv',[dict(view=k[0],task=k[1],visibility=k[2],mode=k[3],truncated_support=k[4],n=v) for k,v in sorted(counts.items())])
    pair=[]
    for k, items in bundles.items():
        bytask={x['task_name']:x for x in items}
        pair.append({'tile_id':k[0],'pid':k[1],'n_tasks':len(items),'n_distinct_inputs':len({fingerprint(x['context']['series']) for x in items}),
                     'c_pair_present':all(t in bytask for t in ['C1_step_time','C2_step_mag']),
                     'b_pair_present':all(t in bytask for t in ['B1_seasonality_present','B2_seasonality_amp'])})
    save('balanced_pairing.csv',pair)
    alt=[]
    with paths[2].open(encoding='utf8',newline='') as f:
        for r in csv.DictReader(f):
            for field,task in [('c1_id','C1_step_time'),('c2_id','C2_step_mag')]:
                i=r[field]
                if not i or i not in gold: continue
                for view,dataset in [('released',gold),('uniform_last64',uniform)]:
                    x=dataset[i]; event=r['alt_c1_answer']
                    alt.append({'view':view,'id':i,'task':task,'alt_answer':r['alt_c1_answer' if field=='c1_id' else 'alt_c2_answer'],
                                'alt_date':event,'visibility':visibility(event,x['context']['series']['t_iso']),
                                'released_answer':gold[i]['answer'],'alt_delta_definition':'median_post_minus_median_pre_detrended_deseasoned',
                                'released_delta_definition':'raw_adjacent_jump'})
    save('alternative_event_visibility.csv',alt)
    counts=Counter((r['view'],r['task'],r['visibility']) for r in alt)
    save('alternative_visibility_summary.csv',[dict(view=k[0],task=k[1],visibility=k[2],n=v) for k,v in sorted(counts.items())])
    # Stored fitting range is observable provenance, unlike conjecturing cache execution.
    baseline_path=DATA/'preds/baseline_v3_llmonly.jsonl'; mismatches=[]
    for p in records(baseline_path):
        x=gold.get(p['id'])
        if x is None: continue
        dates=x['context']['series']['t_iso']; st=p.get('stats',{})
        if st.get('start')!=dates[0].replace('-','') or st.get('end')!=dates[-1].replace('-','') or st.get('n')!=len(dates):
            mismatches.append({'id':p['id'],'task':x['task_name'],'saved_start':st.get('start'),'saved_end':st.get('end'),
                               'expected_start':dates[0],'expected_end':dates[-1],'saved_n':st.get('n'),'expected_n':len(dates)})
    save('baseline_window_mismatches.csv',mismatches)
    summary={'balanced_qa':len(gold),'balanced_series':len(bundles),'complete_six_task_series':sum(r['n_tasks']==6 for r in pair),
             'series_with_multiple_inputs':sum(r['n_distinct_inputs']>1 for r in pair),
             'baseline_saved_range_mismatches':len(mismatches),'baseline_mismatches_by_task':dict(Counter(r['task'] for r in mismatches)),
             'c2_adjacent_checks':dict(Counter(str(r['gold_matches_adjacent_round1']) for r in rows if 'gold_matches_adjacent_round1' in r)),
             'visible_event_without_left_by_view_task':dict(Counter(r['view']+'/'+r['task'] for r in rows if r.get('left_observation_available') is False)),
             'uniform_labels_identical':all(x['answer']==gold[i]['answer'] for i,x in uniform.items()),'api_calls':0}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    paths += [natural_path,baseline_path,Path(__file__)]
    manifest=[]
    for p in paths:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(8*1024*1024),b''): h.update(chunk)
        manifest.append({'path':str(p),'sha256':h.hexdigest()})
    (OUT/'input_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
