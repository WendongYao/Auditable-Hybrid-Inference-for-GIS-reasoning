from pathlib import Path
import sys,json,csv
from collections import defaultdict
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'scripts'))
import score
groups=defaultdict(list)
for line in (root/'scoring_correction_20261016/alternative_replay_inputs.jsonl').open():
    r=json.loads(line);g=r['gold']
    if g['task_name'].startswith(('B2','C2')):
        assert g['answer_numeric']==(None if g['answer']=='none' else g['answer'])
    for system,p in r['predictions'].items():groups[(r['experiment'],system,g['task_name'])].append(int(score.score_one(g,p)[0]))
expected=list(csv.DictReader((root/'scoring_correction_20261016/historical_summaries/revision_20261001_followup/supporting_metrics.csv').open(encoding='utf-8-sig')))
for exp,system in sorted({(k[0],k[1]) for k in groups}):
    rows=[v for (e,s,t),v in groups.items() if e==exp and s==system]
    macro=sum(sum(v)/len(v) for v in rows)/len(rows);micro=sum(map(sum,rows))/sum(map(len,rows))
    target=next(r for r in expected if r['experiment']==exp and r['system']==system)
    assert abs(macro-float(target['macro']))<1e-12 and abs(micro-float(target['micro']))<1e-12
print('PASS alternative-label replay: 3027 paired QA records, 24 system/definition comparisons; corrected numeric field binding; zero model calls')
