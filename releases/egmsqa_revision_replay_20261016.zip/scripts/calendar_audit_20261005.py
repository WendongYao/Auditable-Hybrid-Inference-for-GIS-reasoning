"""Companion C1 calendar diagnostics from saved outputs; scoring unchanged."""
from datetime import datetime
import numpy as np
import revise_results_20261001 as a
import analyze_gate_20261003 as g
import bounded_exploration_metrics_20261004 as m

def date(v):
    if not isinstance(v,str):return None
    for fmt in ['%Y%m%d','%Y-%m-%d']:
        try:return datetime.strptime(v,fmt).date()
        except ValueError:pass
    return None

def main():
    sets,_=m.load_sets();sets.pop('gpt_noise')
    p=a.DATA/'prospective_frozen_bf_v2_20261005'
    sets['prospective360']=tuple(a.load(p/f) for f in ['dataset_fullprefix.jsonl','predictions_E.jsonl','predictions_H0.jsonl'])
    summary=[];detail=[]
    for group,(ds,e,h) in sets.items():
        branches={'E':e,'H0':h}
        if group=='gpt180':
            for name in ['Raw_LLM','Hybrid_full','Deterministic_full']:
                f=a.DATA/'revision_20261002_matched/preds'/f'{name}.jsonl'
                if f.exists():branches[name]=a.load(f)
        if group=='gemini252':branches['R']=a.load(g.OUT/'metadata_repair/dev/predictions_R.jsonl')
        if group=='prospective360':branches['BF']=a.load(p/'predictions_B_F.jsonl')
        for name,preds in branches.items():
            records=[]
            for i,x in ds.items():
                if x['task_name']!='C1_step_time':continue
                pv=a.val(preds[i]);pd=date(pv);gd=date(x['answer'])
                dates=[date(t) for t in x['context']['series']['t_iso']];assert all(dates)
                valid=pd is not None and not preds[i].get('parse_error')
                r=dict(group=group,branch=name,id=i,gold=x['answer'],prediction=pv,
                       valid_date=bool(valid),date_pair=bool(valid and gd),
                       outside=bool(valid and (pd<min(dates) or pd>max(dates))),
                       error_days=abs((pd-gd).days) if valid and gd else None,
                       index_correct=g.correct(x,preds[i]))
                records.append(r);detail.append(r)
            errs=[r['error_days'] for r in records if r['date_pair']]
            summary.append(dict(group=group,branch=name,n=len(records),valid_dates=sum(r['valid_date'] for r in records),
                                date_pairs=len(errs),outside_grid=sum(r['outside'] for r in records),
                                outside_and_index_correct=sum(r['outside'] and r['index_correct'] for r in records),
                                index_correct=sum(r['index_correct'] for r in records),
                                median_days=float(np.median(errs)) if errs else None,
                                p90_days=float(np.quantile(errs,.9)) if errs else None,
                                max_days=max(errs) if errs else None))
    out=a.DATA/'calendar_audit_20261005';out.mkdir(exist_ok=True)
    a.csvwrite(out/'summary.csv',summary);a.csvwrite(out/'details.csv',detail)
    for r in summary:print(r)

if __name__=='__main__':main()
