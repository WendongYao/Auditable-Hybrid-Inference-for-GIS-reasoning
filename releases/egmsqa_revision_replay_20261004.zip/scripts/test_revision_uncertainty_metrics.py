import unittest
from analyze_revision_uncertainty_20261002 import kind,numeric

class MetricsTests(unittest.TestCase):
    def test_none_failure_zero_and_negative_remain_distinct(self):
        def p(v,error=None):return {'answer_parsed':v,'parse_error':error}
        task='C2_step_mag'
        self.assertEqual(kind(p('none'),task),'none')
        self.assertEqual(kind(p(None,'bad'),task),'invalid')
        self.assertEqual(kind(p(0),task),'zero')
        self.assertEqual(kind(p(-2),task),'negative')
        self.assertIsNone(numeric('none',task))
        self.assertIsNone(numeric(None,task))
        self.assertEqual(numeric(0,task),0.)
    def test_date_distribution_uses_days_not_date_integer_arithmetic(self):
        self.assertEqual(numeric('20200201','C1_step_time')-numeric('20200131','C1_step_time'),1.)
        self.assertIsNone(numeric('not-a-date','C1_step_time'))
        self.assertIsNone(numeric('seasonal','B1_seasonality_present'))

if __name__=='__main__':unittest.main()
