# Real replay cases

Post-hoc illustrative selection: first lexicographic ID satisfying each documented success/failure/gate criterion. The fourth case is the first negative-step series in the outcome-blind frozen selection order. These are explanatory cases, not a representative performance sample.

## rule_corrects_error
ID: `E32N34_40fwiCND5E_B2_seasonality_amp`

Original label: `2.8`; LLM response: `{"answer":4.4}`.
After fixed rules: `2.75`; after gate: `2.75`.
Correctness (operational weak label): LLM=False, rules=True, gate=True.
Prompt hash: `aeef6b37a101753fe7a0f7b63a8fdb6f23b7103a339dfea6e24140af49de9e76`. Full observed series, prompt and response/stages are stored beside this report.

## rule_introduces_error
ID: `E32N34_40fYDEpo3G_B1_seasonality_present`

Original label: `seasonal`; LLM response: `{"answer":"seasonal"}`.
After fixed rules: `nonseasonal`; after gate: `nonseasonal`.
Correctness (operational weak label): LLM=True, rules=False, gate=False.
Prompt hash: `beb16922f73d15e5b409fbf187f360f1f0916a534ad5033f6921250918824244`. Full observed series, prompt and response/stages are stored beside this report.

## gate_changes_answer
ID: `E40N30_20bZ1g9h47_C2_step_mag`

Original label: `5.3`; LLM response: `{"answer":"none"}`.
After fixed rules: `5.3`; after gate: `none`.
Correctness (operational weak label): LLM=False, rules=True, gate=False.
Prompt hash: `093f0f385ce0bd4f22b45156fb31c72dc313d5fedca2a45038b9d59b0908c2b9`. Full observed series, prompt and response/stages are stored beside this report.

Gate antecedent C1_step_time: `none`. The two tasks share the same observation input.

## seed_selected_negative_step
ID: `E32N34_40gFzg0hlr_C2_step_mag`

Original label: `-5.8`; LLM response: `{"answer":-5.8}`.
After fixed rules: `-5.8`; after gate: `-5.8`.
Correctness (operational weak label): LLM=True, rules=True, gate=True.
Prompt hash: `dbc1b684aae0802d494321578e48427883f1eb4b556af1ffb33ef4923b8eff54`. Full observed series, prompt and response/stages are stored beside this report.
