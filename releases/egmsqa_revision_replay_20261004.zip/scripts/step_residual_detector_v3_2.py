# scripts/step_residual_detector_v3_2.py
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

DATE_YYYYMMDD = "%Y%m%d"


def parse_date_any(s: str) -> Optional[datetime]:
    s = str(s).strip()
    for fmt in ("%Y-%m-%d", "%Y%m%d", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            pass
    try:
        return datetime.fromisoformat(s)
    except Exception:
        return None


def yyyymmdd_from_iso(s: str) -> str:
    dt = parse_date_any(s)
    if dt:
        return dt.strftime(DATE_YYYYMMDD)
    digits = "".join([c for c in str(s) if c.isdigit()])
    return digits[:8] if len(digits) >= 8 else str(s)


def _finite_idx(y: List[Any]) -> List[int]:
    idx: List[int] = []
    for i, v in enumerate(y):
        if v is None:
            continue
        try:
            fv = float(v)
        except Exception:
            continue
        if np.isfinite(fv):
            idx.append(i)
    return idx


def _mad_sigma(x: np.ndarray) -> float:
    x = x[np.isfinite(x)]
    if x.size < 5:
        s = float(np.nanstd(x)) if x.size else 1.0
        return s if np.isfinite(s) and s > 1e-9 else 1.0
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    s = mad / 0.6745 if mad > 0 else float(np.nanstd(x))
    return float(s if np.isfinite(s) and s > 1e-9 else 1.0)


def _ols_fit(X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    rss = float(resid.T @ resid)
    n, p = X.shape
    dof = max(1, n - p)
    sigma2 = rss / dof
    sigma = float(np.sqrt(sigma2))
    return {"beta": beta, "resid": resid, "rss": rss, "sigma": sigma, "dof": dof}


def _robust_ols_fit(X: np.ndarray, y: np.ndarray, iters: int = 2, clip: float = 4.5) -> Dict[str, Any]:
    """
    Very light robustification:
      - OLS
      - compute MAD sigma on resid
      - mask |resid| <= clip*sigma
      - refit (repeat)
    """
    mask = np.ones(y.shape[0], dtype=bool)
    fit = _ols_fit(X, y)
    for _ in range(max(0, int(iters))):
        resid = np.asarray(fit["resid"], dtype=np.float64)
        s = _mad_sigma(resid[mask])
        thr = clip * max(1e-9, s)
        new_mask = np.isfinite(resid) & (np.abs(resid) <= thr)
        # keep at least p+6 points (avoid collapsing)
        if int(new_mask.sum()) < X.shape[1] + 6:
            break
        mask = new_mask
        fit = _ols_fit(X[mask], y[mask])
        # project back to full-length residual for downstream
        beta = fit["beta"]
        full_resid = y - X @ beta
        rss = float(np.dot(full_resid, full_resid))
        n = int(y.shape[0])
        p = int(X.shape[1])
        dof = max(1, n - p)
        sigma = float(np.sqrt(rss / dof))
        fit = {"beta": beta, "resid": full_resid, "rss": rss, "sigma": sigma, "dof": dof}

    fit["robust_mask_rate"] = float(mask.mean())
    return fit


def _se_from_xtx(X: np.ndarray, sigma: float, idx: int) -> Optional[float]:
    try:
        xtx = X.T @ X
        inv = np.linalg.inv(xtx)
        v = float(inv[idx, idx]) * (sigma ** 2)
        if v <= 0:
            return None
        return float(np.sqrt(v))
    except Exception:
        return None


def _bic(rss: float, n: int, p: int) -> float:
    if rss <= 1e-12:
        rss = 1e-12
    return float(n * np.log(rss / max(1, n)) + p * np.log(max(2, n)))


def _gap_penalty_days(gap_days: float) -> float:
    """
    Stronger than v3.1:
      - <=30d: ~0
      - 30~120d: moderate
      - >120d: grows faster to discourage huge-gap “fake steps”
    """
    g = max(0.0, float(gap_days))
    if g <= 30.0:
        return 0.0
    x = (g - 30.0) / 60.0  # 60d scale (stronger than 90d)
    return float(np.log1p(x) + 0.15 * max(0.0, x - 1.5))


def _window_stats(arr: np.ndarray, j: int, k: int) -> Dict[str, Any]:
    pre = arr[j - k: j]
    post = arr[j: j + k]
    pre_med = float(np.median(pre))
    post_med = float(np.median(post))
    mag = post_med - pre_med
    mag_abs = float(abs(mag))
    closer = float(np.mean(np.abs(post - post_med) <= np.abs(post - pre_med)))
    return {
        "pre_med": pre_med,
        "post_med": post_med,
        "mag": float(mag),
        "mag_abs": mag_abs,
        "closer_frac": closer,
    }


def _persist_long(arr: np.ndarray, j: int, pre_len: int, post_len: int) -> Tuple[float, bool]:
    """
    Long-window persistence:
      - take longer pre/post slices (bounded by available points)
      - persist_frac := fraction of post points closer to post_med than pre_med
    """
    n = int(arr.size)
    a = max(0, j - pre_len)
    b = j
    c = j
    d = min(n, j + post_len)
    if (b - a) < 3 or (d - c) < 3:
        return 0.0, False
    pre = arr[a:b]
    post = arr[c:d]
    pre_med = float(np.median(pre))
    post_med = float(np.median(post))
    frac = float(np.mean(np.abs(post - post_med) <= np.abs(post - pre_med)))
    return frac, True


@dataclass
class StepThresholds:
    # keep loose for recall; strict for “strong evidence” (gate can choose)
    loose_mag_abs_mm: float = 1.5
    loose_snr: float = 1.0
    loose_improve_frac: float = 0.01
    loose_delta_bic: float = 2.0

    strict_mag_abs_mm: float = 2.0
    strict_snr: float = 1.5
    strict_improve_frac: float = 0.02
    strict_delta_bic: float = -2.0

    persist_frac: float = 0.70  # gate-friendly threshold


def scan_step_on_residual(
    t_iso: List[str],
    y_mm: List[Any],
    rmse_mm: Optional[float] = None,
    k_side: int = 3,
    topk: int = 5,
) -> Dict[str, Any]:
    """
    v3.2 improvements over v3.1:
      - robust base fit (trend + annual season) to build residual
      - stronger gap penalty + refine prefers smaller-gap break when evidence similar
      - persist_frac uses long-window persistence (more stable than k_side-only)
      - optional slope-break (hinge) comparison to suppress false steps from trend kinks
    Output keys keep v3.1-compatible; additionally best includes:
      date, mag_abs_mm, snr, improve_frac, delta_bic, persist_flag, persist_frac
    """
    thr = StepThresholds()

    valid = _finite_idx(y_mm)
    if len(valid) < (2 * k_side + 6):
        return {"present": False, "reason": "insufficient_valid"}

    t0 = parse_date_any(t_iso[valid[0]])
    if not t0:
        return {"present": False, "reason": "bad_time"}

    t_days: List[float] = []
    y: List[float] = []
    vidx: List[int] = []
    for i in valid:
        dt = parse_date_any(t_iso[i])
        if not dt:
            continue
        t_days.append(float((dt - t0).days))
        y.append(float(y_mm[i]))
        vidx.append(i)

    t_days_arr = np.asarray(t_days, dtype=np.float64)
    y_arr = np.asarray(y, dtype=np.float64)
    n = int(y_arr.size)
    if n < (2 * k_side + 6):
        return {"present": False, "reason": "insufficient_time_parsed"}

    # base model: 1 + t_years + sin + cos
    t_years = t_days_arr / 365.25
    w = 2.0 * np.pi / 365.25
    sin1 = np.sin(w * t_days_arr)
    cos1 = np.cos(w * t_days_arr)
    X0 = np.stack([np.ones(n), t_years, sin1, cos1], axis=1)

    fit0 = _robust_ols_fit(X0, y_arr, iters=2, clip=4.5)
    rss0 = float(fit0["rss"])
    resid0 = np.asarray(fit0["resid"], dtype=np.float64)
    base_mask_rate = float(fit0.get("robust_mask_rate", 1.0))

    sigma_used = float(rmse_mm) if (rmse_mm is not None and rmse_mm > 0) else _mad_sigma(resid0)
    bic0 = _bic(rss0, n=n, p=X0.shape[1])

    # window sizes: small for C1 alignment; bigger for stability
    k_small = int(max(2, k_side))
    k_big = int(max(k_small + 2, 5))
    pre_len = int(max(2 * k_small, 6))
    post_len = int(max(2 * k_small, 6))

    # ---------------- Stage-1: local jump candidates on residual ----------------
    min_seg = max(k_small + 1, 4)
    stage1: List[Tuple[float, int, Dict[str, Any]]] = []
    for j in range(min_seg, n - min_seg):
        if j - k_small < 0 or j + k_small > n:
            continue

        gap_days = float(t_days_arr[j] - t_days_arr[j - 1])
        gpen = _gap_penalty_days(gap_days)

        ws_r_s = _window_stats(resid0, j=j, k=k_small)
        ws_r_b = _window_stats(resid0, j=j, k=min(k_big, j, n - j))

        ws_y_s = _window_stats(y_arr, j=j, k=k_small)

        # adjacency deltas (use residual too)
        adj_y = float(y_arr[j] - y_arr[j - 1])
        adj_r = float(resid0[j] - resid0[j - 1])

        persist_frac, persist_ok = _persist_long(resid0, j=j, pre_len=pre_len, post_len=post_len)
        persist_flag = bool(persist_ok and persist_frac >= thr.persist_frac)

        # stronger “gap avoidance”: make gap hurt more than v3.1
        score1 = (
            (max(ws_r_s["mag_abs"], ws_r_b["mag_abs"]) / max(1e-9, sigma_used)) * 1.10
            + (ws_y_s["mag_abs"] / max(1e-9, sigma_used)) * 0.25
            + (abs(adj_r) / max(1e-9, sigma_used)) * 0.25
            + (abs(adj_y) / max(1e-9, sigma_used)) * 0.10
            + (0.75 if persist_flag else 0.0)
            - gpen * 1.25
        )

        info = {
            "j": int(j),
            "left_iso": str(t_iso[vidx[j - 1]]),
            "right_iso": str(t_iso[vidx[j]]),
            "step_date_candidate": yyyymmdd_from_iso(t_iso[vidx[j]]),
            "gap_days": float(gap_days),
            "gap_penalty": float(gpen),
            "raw_adj_delta_mm": float(adj_y),
            "resid_adj_delta_mm": float(adj_r),
            "raw_window_mag_mm": float(ws_y_s["mag"]),
            "raw_window_mag_abs_mm": float(ws_y_s["mag_abs"]),
            "resid_window_mag_mm": float(ws_r_s["mag"]),
            "resid_window_mag_abs_mm": float(ws_r_s["mag_abs"]),
            "resid_window_mag_abs_mm_big": float(ws_r_b["mag_abs"]),
            "persist_frac": float(persist_frac),
            "persist_flag": bool(persist_flag),
            "stage1_score": float(score1),
        }
        stage1.append((float(score1), int(j), info))

    if not stage1:
        return {"present": False, "reason": "no_candidates_stage1"}

    stage1.sort(key=lambda x: x[0], reverse=True)
    stage1_keep = stage1[: max(16, int(topk) * 5)]

    # ---------------- Stage-2: segmented regression evidence ----------------
    stage2: List[Tuple[float, int, Dict[str, Any]]] = []

    def eval_break(j: int, base_info: Dict[str, Any]) -> Optional[Tuple[float, int, Dict[str, Any]]]:
        if j < min_seg or j > n - min_seg:
            return None

        # Step model
        H = np.zeros(n, dtype=np.float64)
        H[j:] = 1.0
        X1 = np.concatenate([X0, H[:, None]], axis=1)
        fit1 = _ols_fit(X1, y_arr)
        rss1 = float(fit1["rss"])
        sigma1 = float(fit1["sigma"])
        beta1 = fit1["beta"]
        step_coef = float(beta1[-1])
        mag_abs_seg = float(abs(step_coef))

        se_step = _se_from_xtx(X1, sigma1, idx=X1.shape[1] - 1)
        snr = float(abs(step_coef) / se_step) if (se_step is not None and se_step > 0) else float(mag_abs_seg / max(1e-9, sigma_used))

        improve = (rss0 - rss1) / rss0 if rss0 > 1e-12 else 0.0
        bic1 = _bic(rss1, n=n, p=X1.shape[1])
        delta_bic = float(bic1 - bic0)

        # Slope-break (hinge) comparison (optional suppress FP)
        # Model: 1 + t + sin + cos + hinge(t - t_j)
        hinge = np.zeros(n, dtype=np.float64)
        hinge[j:] = (t_years[j:] - t_years[j])
        Xs = np.concatenate([X0, hinge[:, None]], axis=1)
        fits = _ols_fit(Xs, y_arr)
        rss_s = float(fits["rss"])
        bic_s = _bic(rss_s, n=n, p=Xs.shape[1])
        delta_bic_slope = float(bic_s - bic0)
        slope_better = bool(delta_bic_slope < delta_bic - 1.0)  # slope improves BIC more than step by margin

        # windows + long persistence
        ws_y = _window_stats(y_arr, j=j, k=k_small)
        ws_r = _window_stats(resid0, j=j, k=k_small)

        persist_frac, persist_ok = _persist_long(resid0, j=j, pre_len=pre_len, post_len=post_len)
        persist_flag = bool(persist_ok and persist_frac >= thr.persist_frac)

        gap_days = float(t_days_arr[j] - t_days_arr[j - 1])
        gpen = _gap_penalty_days(gap_days)

        # Score: evidence - gap - (slope-better penalty)
        slope_pen = 0.0
        if slope_better:
            slope_pen = 0.6 + 0.15 * max(0.0, (-delta_bic_slope) - (-delta_bic))

        score2 = (
            snr * 1.0
            + improve * 6.0
            + max(0.0, -delta_bic) * 0.28
            + (1.0 if persist_flag else 0.0)
            + (ws_y["mag_abs"] / max(1e-9, sigma_used)) * 0.18
            - gpen * 1.45
            - slope_pen
        )

        out = dict(base_info)
        out.update({
            "seg_step_coef_mm": float(step_coef),
            "seg_step_coef_abs_mm": float(mag_abs_seg),
            "snr": float(snr),
            "improve_frac": float(improve),
            "delta_bic": float(delta_bic),
            "delta_bic_slope": float(delta_bic_slope),
            "slope_better_than_step": bool(slope_better),
            "rss0": float(rss0),
            "rss1": float(rss1),
            "rss_slope": float(rss_s),
            "sigma_used_mm": float(sigma_used),
            "raw_window_mag_mm": float(ws_y["mag"]),
            "raw_window_mag_abs_mm": float(ws_y["mag_abs"]),
            "resid_window_mag_mm": float(ws_r["mag"]),
            "resid_window_mag_abs_mm": float(ws_r["mag_abs"]),
            "persist_frac": float(persist_frac),
            "persist_flag": bool(persist_flag),
            "stage2_score": float(score2),
            "base_fit_mask_rate": float(base_mask_rate),
        })

        # Gate / downstream-friendly canonical keys
        out["mag_mm"] = float(ws_y["mag"])
        out["mag_abs_mm"] = float(ws_y["mag_abs"])
        out["date"] = yyyymmdd_from_iso(t_iso[vidx[j]])
        out["step_date_candidate"] = out["date"]

        return (float(score2), int(j), out)

    # eval stage2 for each stage1 candidate + neighbors (±1)
    for _, j, info in stage1_keep:
        for jj in (j - 1, j, j + 1):
            if jj <= 0 or jj >= n:
                continue
            base = dict(info)
            base["j"] = int(jj)
            base["left_iso"] = str(t_iso[vidx[jj - 1]])
            base["right_iso"] = str(t_iso[vidx[jj]])
            base["step_date_candidate"] = yyyymmdd_from_iso(t_iso[vidx[jj]])
            e = eval_break(jj, base)
            if e is not None:
                stage2.append(e)

    if not stage2:
        return {
            "present": False,
            "sigma_mm": float(sigma_used),
            "thresholds": {},
            "candidates_topk": [c[2] for c in stage1[: max(1, int(topk))]],
            "reason": "no_candidates_stage2",
        }

    stage2.sort(key=lambda x: x[0], reverse=True)
    best = stage2[0][2]
    best_j = int(best["j"])

    # ---------------- Refine: local re-scan prefers smaller-gap when evidence similar ----------------
    refine_radius = 3
    refine_pool: List[Tuple[float, int, Dict[str, Any]]] = []
    for jj in range(max(min_seg, best_j - refine_radius), min(n - min_seg, best_j + refine_radius) + 1):
        base = dict(best)
        base["j"] = int(jj)
        base["left_iso"] = str(t_iso[vidx[jj - 1]])
        base["right_iso"] = str(t_iso[vidx[jj]])
        base["step_date_candidate"] = yyyymmdd_from_iso(t_iso[vidx[jj]])
        e = eval_break(jj, base)
        if e is None:
            continue
        cand = e[2]
        # refine composite: keep stage2_score primary; add raw jump; penalize gap strongly; penalize moving too far
        gpen = float(cand.get("gap_penalty", 0.0))
        move_pen = 0.10 * float(abs(jj - best_j))
        refine_score = (
            float(cand.get("stage2_score", 0.0)) * 1.0
            + (float(cand.get("raw_window_mag_abs_mm", 0.0)) / max(1e-9, sigma_used)) * 0.25
            + (0.25 if cand.get("persist_flag") else 0.0)
            - gpen * 1.80
            - move_pen
        )
        cand["refine_score"] = float(refine_score)
        refine_pool.append((float(refine_score), int(jj), cand))

    if refine_pool:
        refine_pool.sort(key=lambda x: x[0], reverse=True)
        best = refine_pool[0][2]

    # ---------------- present decision (loose + strict) ----------------
    def present_loose(b: Dict[str, Any]) -> bool:
        return (
            (float(b.get("mag_abs_mm", 0.0)) >= thr.loose_mag_abs_mm)
            and (float(b.get("snr", 0.0)) >= thr.loose_snr)
            and (float(b.get("improve_frac", 0.0)) >= thr.loose_improve_frac)
            and bool(b.get("persist_flag", False))
            and (float(b.get("delta_bic", 0.0)) <= thr.loose_delta_bic)
        )

    def present_strict(b: Dict[str, Any]) -> bool:
        return (
            (float(b.get("mag_abs_mm", 0.0)) >= thr.strict_mag_abs_mm)
            and (float(b.get("snr", 0.0)) >= thr.strict_snr)
            and (float(b.get("improve_frac", 0.0)) >= thr.strict_improve_frac)
            and bool(b.get("persist_flag", False))
            and (float(b.get("delta_bic", 0.0)) <= thr.strict_delta_bic)
        )

    p_loose = bool(present_loose(best))
    p_strict = bool(present_strict(best))
    present = p_loose

    # window dump around best (debug-friendly)
    j = int(best["j"])
    win = []
    for ii in range(max(0, j - 6), min(n, j + 7)):
        win.append({
            "i": int(ii),
            "iso": str(t_iso[vidx[ii]]),
            "yyyymmdd": yyyymmdd_from_iso(t_iso[vidx[ii]]),
            "y_mm": float(y_arr[ii]),
            "resid0_mm": float(resid0[ii]),
        })

    best["window_around_best"] = win
    best["present_loose"] = p_loose
    best["present_strict"] = p_strict

    # final: candidates_topk from stage2
    top_candidates = [c[2] for c in stage2[: max(1, int(topk))]]

    return {
        "present": bool(present),
        "best": best,
        "sigma_mm": float(sigma_used),
        "thresholds": {
            "persist_frac": thr.persist_frac,
            "loose": {
                "mag_abs_mm": thr.loose_mag_abs_mm,
                "snr": thr.loose_snr,
                "improve_frac": thr.loose_improve_frac,
                "delta_bic": thr.loose_delta_bic,
            },
            "strict": {
                "mag_abs_mm": thr.strict_mag_abs_mm,
                "snr": thr.strict_snr,
                "improve_frac": thr.strict_improve_frac,
                "delta_bic": thr.strict_delta_bic,
            },
        },
        "candidates_topk": top_candidates,
        "reason": "ok" if present else "below_threshold",
    }
