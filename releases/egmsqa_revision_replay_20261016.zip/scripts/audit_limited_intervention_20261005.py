"""Retrospective offline audit; independent predicates, immutable input files, no API."""
import csv
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import numpy as np
import revise_results_20261001 as a
import analyze_gate_20261003 as g

SRC = a.DATA / 'prospective_frozen_bf_v2_20261005'
OUT = a.DATA / 'limited_intervention_audit_20261005'
PROTOCOL = a.ROOT.parent/'revision/21_limited_intervention_audit_protocol_20261005.md'
if not PROTOCOL.exists():
    PROTOCOL = a.ROOT/'revision/21_limited_intervention_audit_protocol_20261005.md'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)

def valid(p):
    return not p.get('parse_error') and p.get('answer_parsed') is not None

def fit(x):
    s = x['context']['series']
    t = s['t_iso']; y = s['d_mm']
    assert len(t) == len(y)
    origin = dt.date.fromisoformat(t[0])
    pairs = [((dt.date.fromisoformat(d)-origin).days/365.25, v)
             for d, v in zip(t, y) if finite(v)]
    if len(pairs) < 6:
        return None
    z = np.array(pairs)
    design = np.column_stack((np.sin(2*np.pi*z[:,0]), np.cos(2*np.pi*z[:,0]), np.ones(len(z))))
    co, _, rank, _ = np.linalg.lstsq(design, z[:,1], rcond=None)
    return float(np.hypot(co[0], co[1])) if rank == 3 else None

def decide(x, e, h):
    ev, hv = e['answer_parsed'], h['answer_parsed']
    task = x['task_name']; q = fit(x) if task == 'B2_seasonality_amp' else None
    f = not valid(e) and task.startswith(('B','C')) and valid(h)
    eligible = task == 'B2_seasonality_amp' and valid(e) and valid(h) and finite(ev) and finite(hv) and ev >= 0 and hv >= 0
    b = bool(eligible and q is not None and q >= .5 and abs(hv-q) <= .125+1e-9 and abs(ev-q) > .5+1e-9)
    assert not (b and f)
    return {'component': 'B' if b else 'F' if f else 'KEEP', 'q_mm': q,
            'rule_gap_mm': abs(hv-q) if q is not None and finite(hv) else None,
            'E_gap_mm': abs(ev-q) if q is not None and finite(ev) else None,
            'final': hv if b or f else ev}

def main():
    OUT.mkdir(exist_ok=True)
    inp = a.load(SRC/'inputs_only.jsonl')
    preds = {n:a.load(SRC/f'predictions_{n}.jsonl') for n in ['E','H0','B_F']}
    raw = {}
    for p in sorted((SRC/'api').glob('*.json')):
        r = json.loads(p.read_text(encoding='utf8'))
        if 'response' in r and 'candidates' in r['response']:
            assert r['id'] not in raw
            raw[r['id']] = (p, r)
    assert set(inp) == set(raw) == set(preds['E']) == set(preds['H0']) == set(preds['B_F'])
    traces = []; checks = []
    # No labels are loaded until after all decisions and traces have been constructed.
    for i in sorted(inp):
        x = inp[i]; e = preds['E'][i]; h = preds['H0'][i]; p, r = raw[i]
        d = decide(x,e,h)
        replay_ok = d['final'] == preds['B_F'][i]['answer_parsed']
        expected_error = None if d['component'] != 'KEEP' else e.get('parse_error')
        replay_ok &= expected_error == preds['B_F'][i].get('parse_error')
        raw_ok = r.get('answer_parsed') == e['answer_parsed'] and r.get('parse_error') == e.get('parse_error')
        traces.append({'id':i,'task':x['task_name'],'inputs_file':str(SRC/'inputs_only.jsonl'),
                       'input_sha256':hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest(),
                       'raw_file':str(p),'raw_sha256':sha(p),
                       'finish_reasons':[c.get('finishReason') for c in r['response']['candidates']],
                       'E':e,'H0':h,**d})
        checks.append({'id':i,'replay_matches':bool(replay_ok),'saved_raw_parse_matches':raw_ok,
                       'invalid_E':not valid(e),'component':d['component']})
    a.jsonlwrite(OUT/'traces_without_gold.jsonl',traces)
    a.csvwrite(OUT/'replay_checks.csv',checks)
    gold = a.load(SRC/'dataset_fullprefix.jsonl'); evaluation = []; cases = {}
    for t in traces:
        i=t['id']; e=preds['E'][i]; h=preds['H0'][i]; f=preds['B_F'][i]
        ec,hc,fc = [g.correct(gold[i],v) for v in [e,h,f]]
        evaluation.append({'id':i,'task':t['task'],'component':t['component'],
                           'E_correct':ec,'H0_correct':hc,'BF_correct':fc,
                           'BF_help':not ec and fc,'BF_harm':ec and not fc,
                           'H0_harm':ec and not hc})
        kinds=[]
        if t['component']=='B':kinds.append('B_intervention')
        if t['component']=='F':kinds.append('F_intervention')
        if not valid(e) and t['component']=='KEEP':kinds.append('invalid_preserved')
        if ec and not hc:kinds.append('broad_override_harm')
        if not fc:kinds.append('remaining_error')
        for k in kinds:
            if k not in cases:cases[k]={'trace':t,'evaluation':evaluation[-1],'gold_for_evaluation_only':gold[i]['answer']}
    a.csvwrite(OUT/'evaluation_separate.csv',evaluation)
    historic = a.DATA/'bounded_exploration_round2_20261005/changed_examples.csv'
    with historic.open(encoding='utf-8-sig',newline='') as f:
        harms=[r for r in csv.DictReader(f) if r['group']=='gpt_noise' and r['candidate']=='B_F' and r['baseline']=='E' and r['harmed']=='1']
    a.csvwrite(OUT/'all_historical_noise_harms.csv',harms)
    a.dump(OUT/'illustrative_cases.json',cases)
    bounds=[]
    for t in traces:
        x=gold[t['id']]
        if t['task']=='B2_seasonality_amp' and x['answer']!='none':
            y=float(x['answer']);bounds.append({'id':t['id'],'q_label_gap':abs(t['q_mm']-y),
                                               'B_applied':t['component']=='B',
                                               'replacement_label_gap':abs(t['final']-y) if finite(t['final']) else None})
    a.csvwrite(OUT/'label_construction_bounds.csv',bounds)
    report={'design':'retrospective mechanical replay and transition attribution, not blinded fault localization',
            'n':len(inp),'replay_matches':sum(r['replay_matches'] for r in checks),
            'saved_raw_parse_matches':sum(r['saved_raw_parse_matches'] for r in checks),
            'invalid_E':sum(r['invalid_E'] for r in checks),
            'actions':{k:sum(t['component']==k for t in traces) for k in ['B','F','KEEP']},
            'BF_help':sum(r['BF_help'] for r in evaluation),'BF_harm':sum(r['BF_harm'] for r in evaluation),
            'H0_harm':sum(r['H0_harm'] for r in evaluation),'remaining_errors':sum(not r['BF_correct'] for r in evaluation),
            'historical_noise_harms':len(harms),'numeric_B2_labels':len(bounds),
            'max_q_label_gap':max(r['q_label_gap'] for r in bounds),
            'max_B_replacement_label_gap':max(r['replacement_label_gap'] for r in bounds if r['B_applied']),
            'new_api_calls':0,'human_audit_efficiency_measured':False,
            'source_hashes':{str(p):sha(p) for p in [Path(__file__),SRC/'inputs_only.jsonl',SRC/'dataset_fullprefix.jsonl',historic,*[SRC/f'predictions_{n}.jsonl' for n in preds],PROTOCOL]}}
    a.dump(OUT/'summary.json',report)
    assert report['replay_matches']==len(inp) and report['saved_raw_parse_matches']==len(inp)
    print(json.dumps({k:v for k,v in report.items() if k!='source_hashes'},indent=2))

if __name__=='__main__':
    main()
