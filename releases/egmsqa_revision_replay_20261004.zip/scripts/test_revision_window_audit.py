import copy
import unittest
import json
import tempfile
from pathlib import Path
from run_baseline_v3 import series_cache_key
from revision_window_audit_20261002 import visibility
from revision_matched_protocol_20261002 import compose

class WindowTests(unittest.TestCase):
    def test_event_outside_is_not_none(self):
        grid=['2020-02-01','2020-02-07']
        self.assertEqual(visibility('20200101',grid),'before_window')
        self.assertEqual(visibility('none',grid),'no_event_label')
        self.assertEqual(visibility(None,grid),'unknown_event_date')
        self.assertEqual(visibility('20200204',grid),'inside_range_not_observed')
    def test_same_point_different_inputs_do_not_share_stats(self):
        a={'id':'tile_pid_A1_trend_dir','context':{'series':{'t_iso':['2020-01-01'],'d_mm':[1.]},'static':{'rmse_mm':1.}}}
        b=copy.deepcopy(a); b['context']['series']['d_mm'][0]=2.
        self.assertNotEqual(series_cache_key(a),series_cache_key(b))
        b=copy.deepcopy(a); b['context']['series']['t_iso'][0]='2020-02-01'
        self.assertNotEqual(series_cache_key(a),series_cache_key(b))
        b=copy.deepcopy(a); b['context']['static']['rmse_mm']=2.
        self.assertNotEqual(series_cache_key(a),series_cache_key(b))
        b=copy.deepcopy(a); b['id']='tile_pid_C1_step_time'
        self.assertEqual(series_cache_key(a),series_cache_key(b))
    def test_non_target_placeholders_cannot_override_answers(self):
        base={f'x_{task}':{'id':f'x_{task}','task_name':task,'answer_parsed':answer}
              for task,answer in [('A1_trend_dir','uplifting'),('C1_step_time','20200101'),('C2_step_mag',3.)]}
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)
            for name in ['b1','b2','c1']:(p/f'{name}.jsonl').write_text('')
            rows=[{**v,'answer_parsed':-2.4 if v['task_name']=='C2_step_mag' else None} for v in base.values()]
            (p/'c2.jsonl').write_text('\n'.join(map(json.dumps,rows)))
            rules,full=compose(base,p)
            self.assertEqual(rules['x_A1_trend_dir']['answer_parsed'],'uplifting')
            self.assertEqual(full['x_C1_step_time']['answer_parsed'],'20200101')
            self.assertEqual(full['x_C2_step_mag']['answer_parsed'],-2.4)
            self.assertEqual(base['x_C2_step_mag']['answer_parsed'],3.)

if __name__=='__main__': unittest.main()
