from pathlib import Path
import csv,hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
for p,h in m['files'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
d=r/'egmsqa/out_qa_v5_8/revision_evidence_audit_20261004'
files=list(d.glob('*.csv'))+list(d.glob('*.jsonl'))
before={p:p.read_bytes() for p in files}
subprocess.run([sys.executable,str(r/'scripts/revision_evidence_audit_20261004.py')],check=True)
for p,b in before.items():assert p.read_bytes()==b,('replay mismatch',p.name)
print('PASS extended replay:',len(files),'tables/predictions; zero API calls')
