"""Frozen-prediction audit: C1 protocol, signed C2 and genuine cumulative B8.

No API calls, tuning, label changes, or writes to historical prediction files.
Run from any directory with the same Python dependencies as score.py.
"""
import argparse
import copy
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import score
import score2 as paper_legacy_score
import predict_c2_from_routeA_a3_prompt as c2
import apply_gate_v3_consistency as gate

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'egmsqa/out_qa_v5_8'
MODELS = ['baseline_v3', 'gemini_batch', 'gemini3flash', 'gemini3pro', 'deepseekv32a3v1', 'gpt52', 'llama4maverick']
FIVE = ['gemini3flash', 'gemini3pro', 'deepseekv32a3v1', 'gpt52', 'llama4maverick']
TASKS = ['A1_trend_dir', 'A2_trend_v', 'B1_seasonality_present', 'B2_seasonality_amp', 'C1_step_time', 'C2_step_mag']
VARIANTS = {
    'ALL_base': None, 'ABL_plus_B1': 'plus_B1', 'ABL_plus_B2': 'plus_B2',
    'ABL_plus_B1B2': 'plus_B1B2', 'ABL_plus_C1': 'plus_C1', 'ABL_plus_C2': 'plus_C2',
    'ABL_plus_C1C2': 'plus_C1C2', 'ABL_plus_B1B2C1': 'plus_B1B2C1_tmp1',
    'ABL_plus_B1B2C1C2': 'plus_B1B2C1C2',
    'GATEv3_consistency_only': 'gatev3_consistency_only',
    'GATEv3_after_C1C2predict': 'gatev3_after_C1C2predict',
    'ABL_plus_B1B2C1C2_plus_gatev3': 'plus_B1B2C1C2_plus_gatev3',
}
GATED = {'GATEv3_consistency_only': 'ALL_base', 'GATEv3_after_C1C2predict': 'ABL_plus_C1C2',
         'ABL_plus_B1B2C1C2_plus_gatev3': 'ABL_plus_B1B2C1C2'}
STAGES = ['ALL_base', 'ABL_plus_B1', 'ABL_plus_B1B2', 'ABL_plus_B1B2C1',
          'ABL_plus_B1B2C1C2', 'ABL_plus_B1B2C1C2_plus_gatev3']


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def csvwrite(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text('', encoding='utf-8'); return
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def jsonlwrite(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        for x in rows: f.write(json.dumps(x, ensure_ascii=False) + '\n')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()


def load(path, compact=False):
    out = {}
    with path.open(encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            x = json.loads(line)
            if x['id'] in out: raise ValueError(f'Duplicate ID in {path}: {x["id"]}')
            if compact:
                x = {k: v for k, v in x.items() if k in ['id','task_name','answer_parsed','answer_numeric','parse_error','use_alt','debug','model']}
            out[x['id']] = x
    return out


def val(x): return x.get('answer_parsed')


def apply_gate(rows):
    out = {i: dict(x) for i, x in rows.items()}
    maps = {t: {gate.base_key(i,t): gate.norm(val(x)) for i,x in rows.items() if x['task_name']==t}
            for t in [gate.TASK_B1,gate.TASK_C1]}
    for i,x in out.items():
        t=x['task_name'];k=gate.base_key(i,t)
        b2=t==gate.TASK_B2 and maps[gate.TASK_B1].get(k,'') in ('nonseasonal','none','no','false','0')
        c2_=t==gate.TASK_C2 and maps[gate.TASK_C1].get(k,'') in ('none','no_step','nostep','no','false','0')
        if b2 or c2_: gate.set_none(x); x['gate_applied']='B1->B2' if b2 else 'C1->C2'
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=DATA/'revision_20261001')
    args=ap.parse_args();out=args.out;out.mkdir(parents=True,exist_ok=True)
    manifest=[]
    def read(rel,compact=False):
        p=DATA/rel; manifest.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
        return load(p,compact)
    gold=read('jsonl/dev_balanced.jsonl')
    print('Loaded gold',len(gold),flush=True)
    prompts=read('prompts/prompts_routeA_a3_summary_28000.jsonl')
    signed={};abs_answers={};candidate_rows=[]
    for i,g in gold.items():
        if g['task_name']!='C2_step_mag':continue
        p=prompts[i]['prompt']; rmse=c2.parse_rmse_mm(p)
        rmse=rmse if rmse is not None and rmse>0 else 1.0
        best,debug=c2.pick_best_candidate(c2.parse_step_candidates(p),rmse,
            c2.parse_window_points(p),c2.parse_anchor_points(p),True,2.7,2.2,0.8,5,0.8,0.55,0.5,0.5)
        old='none' if best is None else c2.answer_from_candidate(best,True,'legacy_absolute')
        new='none' if best is None else c2.answer_from_candidate(best,True,'signed_delta')
        abs_answers[i]=old
        signed[i]={'id':i,'task_name':'C2_step_mag','answer_parsed':new,
                   'answer_numeric':None if new=='none' else new,'parse_error':None,
                   'model':'c2_from_routeA_a3_prompt_v3_signed','debug':debug}
        candidate_rows.append({'id':i,'gold':g['answer'],'old':old,'signed':new,
            'rank':None if best is None else best.cand.rank,
            'step_date':None if best is None else best.cand.step_iso,
            'signed_delta':None if best is None else best.cand.delta_mm,
            'strength':None if best is None else best.mag_used,
            'changed':old!=new})
    jsonlwrite(out/'preds/c2_signed_shared.jsonl',signed.values())
    csvwrite(out/'c2_candidate_audit.csv',candidate_rows)
    print('Recomputed C2 candidates',len(signed),flush=True)
    # Historical development exposure: ID overlap, not filename inference.
    ids560=read('prompts/prompts_summary_560.jsonl')
    history={'pilot_ids':len(ids560),'pilot_overlap_dev_balanced':len(set(ids560)&set(gold)),
             'c2_positive_instruction_count':sum('POSITIVE step magnitude' in x['prompt'] for x in prompts.values()),
             'prompt_file':str(DATA/'prompts/prompts_routeA_a3_summary_28000.jsonl')}
    matrix=DATA/'exp_matrix/20251227_131717'
    history['matrix_runs']=list(csv.DictReader((matrix/'summary_table.csv').open(encoding='utf-8-sig')))
    history['matrix_actual_id_overlaps']=[]
    for p in sorted((matrix/'preds').glob('hybrid*.jsonl')):
        ids=set(load(p,True));history['matrix_actual_id_overlaps'].append({'file':str(p),'n':len(ids),'overlap':len(ids&set(gold))})
    history['b2_sweep']=[str(p.relative_to(DATA)) for p in sorted((DATA/'scores').glob('_hybrid_plus_C2fix7_plus_B2sin*/summary.json'))]
    dump(out/'development_exposure.json',history)
    del prompts
    records=[];buckets=[];legacy_checks=[];invariants=[];gate_changes=[];deltas=[];c1_changes=[]
    cache={}
    def scored(i,p,policy):
        key=(i,json.dumps(val(p),sort_keys=True),str(p.get('parse_error')),policy)
        if key not in cache:
            if policy=='paper_legacy_score2':
                cache[key]=paper_legacy_score.score_one(copy.deepcopy(gold[i]),p)
            else:
                cache[key]=score.score_one(gold[i],p,c1_policy=policy)
        return cache[key]
    for model in MODELS:
        print('Processing',model,flush=True)
        rows_by_variant={}
        for variant,suffix in VARIANTS.items():
            rel=f'preds/{model}_llmonly.jsonl' if suffix is None else f'preds/ablations_v2/{model}_{suffix}.jsonl'
            rows=read(rel,True)
            assert set(rows)<=set(gold),(model,variant,'unknown IDs')
            if rows_by_variant:assert set(rows)==set(rows_by_variant['ALL_base']),(model,variant,'coverage changed')
            rows_by_variant[variant]=rows
        original_rule=read(f'preds/{model}_c2_rule_fix7_pfsoft_sg0.8.jsonl',True)
        mismatch=[i for i in signed if i in original_rule and val(original_rule[i])!=abs_answers[i]]
        assert not mismatch,(model,'C2 legacy reproduction failed',mismatch[:5])
        invariants.append({'model':model,'check':'C2 legacy predictions exactly reproduced','n':len(signed),'failures':len(mismatch)})
        for prev,nxt,target in zip(STAGES[:-2],STAGES[1:-1],TASKS[2:]):
            a,b=rows_by_variant[prev],rows_by_variant[nxt]
            wrong=[i for i in a if gold[i]['task_name']!=target and (val(a[i]),a[i].get('parse_error'))!=(val(b[i]),b[i].get('parse_error'))]
            assert not wrong,(model,prev,nxt,'non-target drift',wrong[:3])
            # Actual target equals independently saved single-task update.
            independent=rows_by_variant['ABL_plus_'+target[:2]]
            wrong_target=[i for i in a if gold[i]['task_name']==target and val(b[i])!=val(independent[i])]
            assert not wrong_target,(model,nxt,'target mismatch')
            invariants.append({'model':model,'check':prev+' -> '+nxt,'n':len(a),'failures':len(wrong)+len(wrong_target)})
        for v,source in GATED.items():
            regenerated=apply_gate(rows_by_variant[source]); saved=rows_by_variant[v]
            bad=[i for i in saved if val(saved[i])!=val(regenerated[i])]
            assert not bad,(model,v,'gate mismatch',bad[:3])
            changes=Counter(gold[i]['task_name'] for i in saved if val(saved[i])!=val(rows_by_variant[source][i]))
            gate_changes.append({'model':model,'variant':v,**{t:changes[t] for t in TASKS}})
        # C1 veto cannot add positive calls, independently of score policy.
        a=rows_by_variant['ALL_base'];b=rows_by_variant['ABL_plus_C1']
        additions=[i for i in a if gold[i]['task_name']=='C1_step_time' and score.norm_str(val(a[i]))=='none' and score.norm_str(val(b[i]))!='none']
        assert not additions,(model,'C1 guard introduced a positive')
        corrected={}
        for v,rows in rows_by_variant.items():
            if v in GATED:continue
            corrected[v]=dict(rows)
            if v in ['ABL_plus_C2','ABL_plus_C1C2','ABL_plus_B1B2C1C2']:
                for i in rows:
                    if gold[i]['task_name']=='C2_step_mag':corrected[v][i]=signed[i]
        for v,source in GATED.items(): corrected[v]=apply_gate(corrected[source])
        for v,rows in corrected.items():
            jsonlwrite(out/f'preds/{model}/{v}.jsonl',rows.values())
        for version,variants in [('legacy_predictions',rows_by_variant),('signed_c2',corrected)]:
            for v,rows in variants.items():
                for policy in ['paper_legacy_score2','legacy_days','acquisition_index_v2']:
                    counts=defaultdict(list);bc=defaultdict(list)
                    for i,p in rows.items():
                        ok,reason=scored(i,p,policy);t=gold[i]['task_name']
                        counts[t].append(int(ok));bc[(t,str(gold[i].get('bucket_label')))].append(int(ok))
                    acc={t:sum(counts[t])/len(counts[t]) for t in TASKS}
                    macro=sum(acc.values())/6;micro=sum(map(sum,counts.values()))/len(rows)
                    rec={'model':model,'prediction_version':version,'variant':v,'c1_policy':policy,
                         'n_scored':len(rows),'coverage':len(rows)/len(gold),'macro':macro,'micro':micro,**acc}
                    records.append(rec)
                    for (t,bucket),values in bc.items():
                        buckets.append({'model':model,'prediction_version':version,'variant':v,'c1_policy':policy,
                                        'task':t,'bucket':bucket,'n':len(values),'acc':sum(values)/len(values)})
                    # Read original score artifacts and require exact aggregate reproduction.
                    oldfile=DATA/f'scores/{model}/{v}/summary.json'
                    if version=='legacy_predictions' and policy=='paper_legacy_score2' and oldfile.exists():
                        old=json.loads(oldfile.read_text(encoding='utf-8'))
                        dm=macro-old['macro_acc_over_tasks'];di=micro-old['micro_acc']
                        legacy_checks.append({'model':model,'variant':v,'macro_delta':dm,'micro_delta':di})
                        assert abs(dm)<1e-12 and abs(di)<1e-12,(model,v,'saved score mismatch',dm,di)
                    if version=='signed_c2' and policy=='acquisition_index_v2':
                        sd=out/f'scores/{model}/{v}'
                        dump(sd/'summary.json',{'mode':'intersection','c1_policy':policy,'prediction_version':version,
                              'n_gold':len(gold),'n_pred':len(rows),'n_scored':len(rows),'n_tasks':6,
                              'coverage_pred_over_gold':len(rows)/len(gold),'macro_acc_over_tasks':macro,'micro_acc':micro})
                        csvwrite(sd/'by_task.csv',[{'task_name':t,'n':len(counts[t]),'acc':acc[t]} for t in TASKS])
                        csvwrite(sd/'by_task_bucket.csv',[{'task_name':t,'bucket_label':b,'n':len(z),'acc':sum(z)/len(z)} for (t,b),z in bc.items()])
        for v,rows in rows_by_variant.items():
            for i,p in rows.items():
                if gold[i]['task_name']!='C1_step_time':continue
                old=scored(i,p,'legacy_days')[0];new=scored(i,p,'acquisition_index_v2')[0]
                details=score.acquisition_index_details(gold[i],val(p))
                if old!=new or (details and (details['gold_outside'] or details['pred_outside'])):
                    c1_changes.append({'model':model,'variant':v,'id':i,'gold':gold[i]['answer'],'prediction':val(p),
                        'old_ok':int(old),'new_ok':int(new),**(details or {k:None for k in ['gold_index','pred_index','index_error','day_error','gold_exact','pred_exact','gold_outside','pred_outside']})})
        for v in VARIANTS:
            for i,p in corrected[v].items():
                oldp=rows_by_variant[v][i]
                if val(oldp)!=val(p):
                    deltas.append({'model':model,'variant':v,'id':i,'task':gold[i]['task_name'],'gold':gold[i]['answer'],
                                   'old_answer':val(oldp),'new_answer':val(p),
                                   'old_ok':int(scored(i,oldp,'acquisition_index_v2')[0]),'new_ok':int(scored(i,p,'acquisition_index_v2')[0])})
        del rows_by_variant,corrected
    csvwrite(out/'all_metrics.csv',records);csvwrite(out/'all_buckets.csv',buckets)
    csvwrite(out/'legacy_reproduction_checks.csv',legacy_checks);csvwrite(out/'stage_invariants.csv',invariants)
    csvwrite(out/'gate_scope_audit.csv',gate_changes);csvwrite(out/'c1_alignment_changes.csv',c1_changes)
    csvwrite(out/'c2_prediction_changes.csv',deltas)
    dump(out/'input_manifest.json',manifest)
    dump(out/'run_summary.json',{'models':MODELS,'five_complete_backbones':FIVE,'n_gold':len(gold),
         'legacy_score_checks':len(legacy_checks),'all_legacy_score_checks_passed':True,
         'stage_checks':len(invariants),'all_stage_checks_passed':True,
         'llm_calls':0,'threshold_changes':0,'label_changes':0,
         'c1_policy':'documented nearest acquisition index; earlier tie, endpoint snapping retained and audited',
         'c2_policy':'signed adjacent delta; absolute strength retained for selection',
         'gate_policy':'both B1->B2 and C1->C2 none consistency; reproduced against historical outputs',
         'warning':'Legacy LLM prompt provenance varies; no semantic-prompt-corrected LLM rerun is claimed.'})
    print('COMPLETE',out,flush=True)


if __name__=='__main__':main()
