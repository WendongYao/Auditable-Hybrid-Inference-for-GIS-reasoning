"""Analyze frozen matched calls, including negative comparisons and replay traces."""
import csv
import json
from collections import defaultdict
import numpy as np
from prepare_revision_matched_subset_20261002 import OUT
from revision_window_audit_20261002 import records
from revision_matched_protocol_20261002 import compose
import revise_results_20261001 as a
import score

def load_api(directory,requests):
    expected={r['request_key']:r for r in records(requests)};found={}
    for path in directory.glob('*.json'):
        r=json.loads(path.read_text(encoding='utf8'))
        k=r['request_key']
        if k not in expected:raise ValueError('unexpected response')
        assert r['prompt_sha256']==expected[k]['prompt_sha256']
        assert r.get('response',{}).get('model')=='gpt-5.2-2025-12-11'
        assert k not in found
        found[k]=r
    assert set(found)==set(expected),('incomplete',len(found),len(expected))
    return found

def pred(r):
    return {k:r.get(k) for k in ['id','task_name','answer_parsed','parse_error']}

def main():
    gold={x['id']:x for x in records(OUT/'dataset_fullprefix.jsonl')}
    calls=load_api(OUT/'api',OUT/'requests_frozen.jsonl')
    systems={name:{r['id']:pred(r) for r in calls.values() if r['branch']==branch} for name,branch in [('Raw_LLM','raw'),('Evidence_LLM','evidence')]}
    rules,full=compose(systems['Evidence_LLM'],OUT/'rules')
    systems.update(Hybrid_no_gate=rules,Hybrid_full=full,Deterministic_full=a.load(OUT/'deterministic_full.jsonl',True))
    metrics=[];per=[];vectors={}
    ids=list(gold)
    for name,ps in systems.items():
        assert set(ps)==set(gold)
        a.jsonlwrite(OUT/f'preds/{name}.jsonl',ps.values())
        tasks=defaultdict(list);byseries=defaultdict(list)
        for i,g in gold.items():
            p=ps[i];ok,reason=score.score_one(g,p); tasks[g['task_name']].append(int(ok));byseries[(g['tile_id'],g['pid'])].append(int(ok))
            per.append({'system':name,'id':i,'task':g['task_name'],'tile':g['tile_id'],'pid':g['pid'],'gold':g['answer'],
                        'prediction':p['answer_parsed'],'ok':int(ok),'reason':reason,'parse_error':p.get('parse_error')})
        vectors[name]=byseries
        metrics.append({'system':name,'n':len(ps),'macro':sum(sum(v)/len(v) for v in tasks.values())/6,
                        'micro':sum(map(sum,tasks.values()))/len(ps),'parse_failure_n':sum(bool(p.get('parse_error')) for p in ps.values()),
                        'none_n':sum(p.get('answer_parsed')=='none' for p in ps.values()),**{t:sum(v)/len(v) for t,v in tasks.items()}})
    a.csvwrite(OUT/'metrics.csv',metrics);a.csvwrite(OUT/'per_example.csv',per)
    # Equal 2-series cells: resample pairs within each fixed tile/sign stratum.
    cells=defaultdict(list)
    for k in vectors['Hybrid_full']:
        ans=gold[f'{k[0]}_{k[1]}_C2_step_mag']['answer']; sign='none' if str(ans)=='none' else 'negative' if float(ans)<0 else 'positive'
        cells[(k[0],sign)].append(k)
    rng=np.random.default_rng(20261002);cis=[]
    for lhs,rhs in [('Hybrid_full','Raw_LLM'),('Hybrid_full','Evidence_LLM'),('Hybrid_full','Deterministic_full'),('Hybrid_full','Hybrid_no_gate'),('Evidence_LLM','Raw_LLM')]:
        diff={k:np.mean(vectors[lhs][k])-np.mean(vectors[rhs][k]) for k in vectors[lhs]}
        boot=[]
        for _ in range(2000):
            boot.append(np.mean([diff[cell[j]] for cell in cells.values() for j in rng.integers(0,len(cell),len(cell))]))
        cis.append({'lhs':lhs,'rhs':rhs,'paired_difference':np.mean(list(diff.values())),'ci_low':np.quantile(boot,.025),'ci_high':np.quantile(boot,.975),
                    'method':'2000 stratified series bootstrap; small development subset, not population generalization'})
    a.csvwrite(OUT/'paired_differences.csv',cis)
    traces=[]
    for i,g in gold.items():
        r=calls['evidence|'+i]
        traces.append({'id':i,'source':g,'prompt_sha256':r['prompt_sha256'],'response_id':r['response']['id'],'LLM_raw_response':r['response'],
                       'LLM_answer':systems['Evidence_LLM'][i],'after_rules':rules[i],'after_gate':full[i],
                       'rule_changed':rules[i]['answer_parsed']!=systems['Evidence_LLM'][i]['answer_parsed'],
                       'gate_changed':full[i]['answer_parsed']!=rules[i]['answer_parsed']})
    a.jsonlwrite(OUT/'audit_traces.jsonl',traces)
    summary={'completed_requests':len(calls),'model':'gpt-5.2-2025-12-11','cost_usd':sum(r['cost_usd'] for r in calls.values()),
             'label_replay_reference_accuracy':1.,'label_replay_interpretation':'180/180 raw-prefix labels reconstructed before inference; not independent validation',
             'metrics':metrics,'gate_changes':sum(t['gate_changed'] for t in traces),'rule_changes':sum(t['rule_changed'] for t in traces)}
    a.dump(OUT/'results_summary.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
