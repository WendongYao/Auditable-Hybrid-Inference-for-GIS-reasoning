"""Predeclare and materialize paired RMSE-scaled perturbation scenarios."""
import copy
import datetime
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from prepare_revision_matched_subset_20261002 import OUT as MATCHED, SEED
from revision_window_audit_20261002 import DATA, records, fingerprint
from revision_matched_protocol_20261002 import make_prompt, local_pipeline
import revise_results_20261001 as a

OUT=DATA/'revision_20261002_uncertainty'

def main():
    OUT.mkdir(exist_ok=True)
    sel=json.loads((MATCHED/'selection.json').read_text())
    # Selection is ordered by stratum, two points per stratum; choose the first.
    selected=[tuple(x) for x in sel['selected'][::2]]
    source={x['id']:x for x in records(MATCHED/'dataset_fullprefix.jsonl')}
    datasets=[]; requests=[]; perturbations=[]
    scenarios=[('unperturbed_repeat',rep) for rep in [1,2]]+[(name,rep) for rep in range(1,21) for name in ['iid_rmse','correlated_rmse_30d']]
    for scenario,rep in scenarios:
        for tile,pid in selected:
            original=source[f'{tile}_{pid}_A1_trend_dir']; s=original['context']['series']
            seed=int(hashlib.sha256(f'{SEED}|{tile}|{pid}|{scenario}|{rep}'.encode()).hexdigest()[:16],16)
            rng=np.random.default_rng(seed);sigma=float(original['context']['static']['rmse_mm'])
            assert sigma>0
            dates=[datetime.date.fromisoformat(t) for t in s['t_iso']]
            z=rng.standard_normal(len(dates))
            if scenario=='unperturbed_repeat':z[:]=0
            elif scenario=='correlated_rmse_30d':
                for j in range(1,len(z)):
                    rho=np.exp(-(dates[j]-dates[j-1]).days/30.)
                    z[j]=rho*z[j-1]+np.sqrt(1-rho*rho)*z[j]
            ys=[None if v is None else (v if scenario=='unperturbed_repeat' else round(float(v)+sigma*float(z[j]),4)) for j,v in enumerate(s['d_mm'])]
            for task in a.TASKS:
                base=source[f'{tile}_{pid}_{task}'];x=copy.deepcopy(base)
                x.update(id=f'{tile}_{pid}_{scenario}{rep:02d}_{task}',source_id=base['id'],scenario=scenario,replicate=rep,perturbation_seed=seed)
                x['context']['series']['d_mm']=ys
                assert x['answer']==base['answer']
                p=make_prompt(x,True)
                datasets.append(x);requests.append({'request_key':'evidence|'+x['id'],'id':x['id'],'source_id':base['id'],'task_name':task,'branch':'evidence',
                    'scenario':scenario,'replicate':rep,'prompt':p,'prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'input_series_sha256':fingerprint(x['context']['series'])})
            perturbations.append({'tile_id':tile,'pid':pid,'scenario':scenario,'replicate':rep,'seed':seed,'sigma_mm':sigma,'noise_mm':(z*sigma).tolist(),
                                  'input_series_sha256':fingerprint(x['context']['series'])})
    assert len(datasets)==len(selected)*42*6
    a.jsonlwrite(OUT/'dataset.jsonl',datasets);a.jsonlwrite(OUT/'requests_frozen.jsonl',requests);a.jsonlwrite(OUT/'perturbations.jsonl',perturbations)
    a.dump(OUT/'frozen_manifest.json',{'selected_series':selected,'series_n':len(selected),'scenario_replicates':20,'unperturbed_additional_repeats':2,
        'requests':len(requests),'dataset_sha256':a.sha(OUT/'dataset.jsonl'),'requests_sha256':a.sha(OUT/'requests_frozen.jsonl'),
        'perturbations_sha256':a.sha(OUT/'perturbations.jsonl'),'script_sha256':a.sha(Path(__file__)),
        'noise_assumptions':'Gaussian iid or exp(-dt/30 days) correlated, marginal SD=RMSE; hypothetical sensitivity, not calibrated uncertainty',
        'rounding':'perturbed input rounded to 4 decimals before all branches; unperturbed input unchanged','labels':'fixed original unperturbed labels',
        'static_metadata':'held fixed; their uncertainty is not propagated'})
    local_pipeline(OUT/'dataset.jsonl',OUT/'rules')
    print('Prepared uncertainty QA:',len(datasets),flush=True)

if __name__=='__main__':main()
