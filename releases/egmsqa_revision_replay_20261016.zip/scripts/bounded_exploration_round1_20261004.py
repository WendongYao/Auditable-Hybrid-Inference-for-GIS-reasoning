"""Six frozen, single-mechanism offline candidates. Never calls a model."""
import copy,json,math,datetime,re
from pathlib import Path
from collections import defaultdict
import bounded_exploration_metrics_20261004 as m
import analyze_gate_20261003 as g
import revise_results_20261001 as a
from revision_evidence_audit_20261004 import whitelist

OUT=a.DATA/'bounded_exploration_20261004'
PLAN=a.ROOT.parent/'revision/13_bounded_exploration_plan_20261004.md'
NAMES=['WARN','FORMAT','FALLBACK','SIGN','NUDGE','VETO']

def valid(p):return not p.get('parse_error') and p.get('answer_parsed') is not None
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def simple(p):return {k:p.get(k) for k in ['id','task_name','answer_parsed','parse_error']}

def candidate(x):
    s=x['context']['series'];y=s['d_mm'];dates=s['t_iso'];rmse=x['context']['static']['rmse_mm']
    dif=[(k,y[k]-y[k-1]) for k in range(1,len(y)) if finite(y[k]) and finite(y[k-1])]
    if not dif or not finite(rmse):return None
    mx=max(abs(v) for k,v in dif);winners=[(k,v) for k,v in dif if abs(abs(v)-mx)<=1e-9]
    if len(winners)!=1 or mx<max(.5,3*rmse):return None
    k,v=winners[0]
    return {'date':dates[k].replace('-',''),'value':round(v,1),'index':k}

def recover(text,task):
    if text is None:return None
    text=text.strip()
    if text.startswith('```') and text.endswith('```'):
        text=re.sub(r'^```(?:json)?\s*','',text,flags=re.IGNORECASE)[:-3].strip()
    try:
        pairs=json.loads(text,object_pairs_hook=lambda pairs:pairs)
        if not isinstance(pairs,list) or len(pairs)!=1 or pairs[0][0]!='answer':return None
        v=pairs[0][1]
        ok=(v in ['subsiding','stable','uplifting'] if task.startswith('A1') else
            v in ['seasonal','nonseasonal'] if task.startswith('B1') else
            finite(v) if task.startswith('A2') else
            v=='none' or (finite(v) and (v>=0 if task.startswith('B2') else True)) if task.startswith(('B2','C2')) else
            v=='none' or isinstance(v,str) and len(v)==8 and datetime.datetime.strptime(v,'%Y%m%d') is not None)
        return v if ok else None
    except (ValueError,TypeError,IndexError):return None

def propose(inputs,e,h,guard,raw):
    ps={n:copy.deepcopy(e) for n in NAMES};log=[]
    for i,x in inputs.items():
        t=x['task_name'];bid=g.base_id(x);ev=e[i]['answer_parsed'];hp=h[i]
        warn=[]
        if ev!=hp['answer_parsed']:warn.append('rule_disagreement')
        if t.startswith(('B2','C2')):
            pt=bid+('_B1_seasonality_present' if t.startswith('B2') else '_C1_step_time')
            pv=e[pt]['answer_parsed'];absent=pv=='nonseasonal' if t.startswith('B2') else pv=='none'
            if valid(e[pt]) and valid(e[i]) and ((absent and finite(ev)) or (not absent and ev=='none')):warn.append('paired_presence_conflict')
        if warn:log.append({'policy':'WARN','id':i,'task':t,'reason':'|'.join(warn),'before':ev,'after':ev})
        changes={}
        if not valid(e[i]):
            r=recover(raw.get(i),t)
            if r is not None:changes['FORMAT']=(r,'unambiguous_full_json_recovery')
            if t.startswith(('B','C')) and valid(hp):changes['FALLBACK']=(hp['answer_parsed'],'invalid_bc_rule_fallback')
        if t=='C2_step_mag' and valid(e[i]) and finite(ev):
            paired=e[bid+'_C1_step_time'];c=candidate(x)
            if c and valid(paired) and paired['answer_parsed']==c['date']:
                cv=c['value']
                if ev*cv<0 and round(abs(ev),1)==round(abs(cv),1):changes['SIGN']=(-ev,'unique_boundary_date_and_rounded_magnitude_agree')
                if ev*cv>0 and 1e-9<abs(ev-cv)<=.1+1e-9:changes['NUDGE']=(cv,'unique_boundary_date_agree_and_delta_le_0.1')
            guardrow=guard.get(bid+'_C1_step_time',{})
            d=guardrow.get('debug',{});fields=['best_abs_mag','best_snr','best_pf','best_edge','best_score']
            complete=all(finite(d.get(k)) for k in fields)
            weak=complete and all(d[k]<=thr for k,thr in zip(fields,[1.2,2.5,.75,2,1.5]))
            if valid(paired) and paired['answer_parsed']=='none' and guardrow.get('use_alt') and weak and valid(hp) and hp['answer_parsed']=='none':
                changes['VETO']=('none','paired_none_and_complete_weak_guard_and_fix7_none')
        for name,(v,reason) in changes.items():
            ps[name][i].update(answer_parsed=v,parse_error=None)
            log.append({'policy':name,'id':i,'task':t,'reason':reason,'before':ev,'after':v})
    return ps,log

def main():
    assert not OUT.exists(),'Completed exploration must not be overwritten'
    OUT.mkdir()
    a.dump(OUT/'freeze.json',{'plan_sha256':a.sha(PLAN),'script_sha256':a.sha(Path(__file__)),
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'round':1,'candidates':NAMES,'new_api_calls':0})
    sets,manifest=m.load_sets();tables=[];details=[];actions=[];alerts=[];verification=[];systems={}
    root=a.DATA
    paths={'gemini252':(g.OUT/'metadata_repair/dev/rules/c1.jsonl',g.OUT/'dev/api'),
           'gpt180':(root/'revision_20261002_matched/rules/c1.jsonl',root/'revision_20261002_matched/api'),
           'gpt_noise':(root/'revision_20261002_uncertainty/rules/c1.jsonl',root/'revision_20261002_uncertainty/api')}
    for group,(dataset,orig_e,orig_h) in sets.items():
        print('Generating',group,flush=True)
        e={i:simple(p) for i,p in orig_e.items()};h={i:simple(p) for i,p in orig_h.items()}
        guardpath,api=paths[group];guards=a.load(guardpath);raw={}
        manifest.append({'path':str(guardpath),'sha256':a.sha(guardpath)})
        # Only invalid responses require raw-text access; no new model calls.
        for p in api.glob('*.json'):
            r=json.loads(p.read_text(encoding='utf-8'));i=r.get('id')
            if i not in e or valid(e[i]) or r.get('branch') not in ['evidence',None]:continue
            resp=r.get('response',{});parts=[]
            if 'candidates' in resp:
                for c in resp['candidates']:
                    parts.extend(z['text'] for z in c.get('content',{}).get('parts',[]) if 'text' in z and not z.get('thought'))
            else:
                for item in resp.get('output',[]):
                    parts.extend(z['text'] for z in item.get('content',[]) if z.get('type')=='output_text')
            assert i not in raw,('duplicate response',i)
            raw[i]=''.join(parts)
            manifest.append({'path':str(p),'sha256':a.sha(p)})
        inp=m.observable_inputs(dataset)
        ps,log=propose(inp,e,h,guards,raw)
        poison=copy.deepcopy(dataset)
        for x in poison.values():x.update(answer='POISON',answer_numeric=999999,bucket_label='POISON',eval={'bad':True},meta={'gold':'POISON'})
        assert ps==propose(m.observable_inputs(poison),e,h,guards,raw)[0]
        assert ps['WARN']==e
        for n in NAMES:
            assert all(p['answer_parsed']==e[i]['answer_parsed'] for i,p in ps[n].items() if e[i]['answer_parsed']=='none' and valid(e[i]))
            a.jsonlwrite(OUT/f'{group}/{n}.jsonl',ps[n].values())
        # E and H0 controls are fixed before any labels are passed to scoring.
        ps.update(E=e,H0=h,OLD_GATE=a.apply_gate(h))
        ps['DEFINITION_REFERENCE']=g.operational_reference(inp.values())
        systems[group]=ps
        original=sets['gpt180'][0] if group=='gpt_noise' else None
        tb,de=m.evaluate(dataset,e,ps,group,original);tables.extend(tb);details.extend(de)
        for item in log:
            item['group']=group;actions.append(item)
            if item['policy']=='WARN':
                x=dataset[item['id']];gold=original[x['source_id']] if original is not None else x
                alerts.append({**item,'original_correct':int(g.correct(gold,e[item['id']]))})
        verification.append({'group':group,'n':len(e),'poison_invariant':True,'none_preserved':True,
                             'warning_answers_unchanged':True,'raw_invalid_responses':len(raw)})
    # Apply registered decision rules only after all outputs have been produced.
    eligible=[];continue_mechanisms=[]
    for n in NAMES:
        rows=[r for r in tables if r['candidate']==n];gem=next(r for r in rows if r['group']=='gemini252' and r['task']=='ALL')
        gt=next(r for r in rows if r['group']=='gpt180' and r['task']=='ALL')
        f=next(r for r in tables if r['candidate']=='FALLBACK' and r['group']=='gemini252' and r['task']=='ALL')
        helped_places={g.base_id({'id':r['id'],'task_name':r['task']}) for r in details if r['group']=='gemini252' and r['candidate']==n and r['helped']}
        passed=(gem['net']>=3 and gem['harmed']<=1 and gem['after_correct']-f['after_correct']>=2 and len(helped_places)>=2
                and gt['harmed']<=1 and all(r['net']>=0 for r in rows if r['group'] in ['gemini252','gpt180'])
                and all(r['net']>=0 for r in rows if r['group']=='gpt_noise' and r['task']=='ALL'))
        if passed:eligible.append(n)
        if n in ['SIGN','NUDGE','VETO'] and gem['net']>=1 and gem['harmed']<=2 and gt['net']>=0:continue_mechanisms.append(n)
    decision={'round':1,'eligible':eligible,'round2_permitted_mechanisms':continue_mechanisms,
              'status':'completed_candidate_found' if eligible else 'round2_mechanism_review' if continue_mechanisms else 'completed_no_qualifying_candidate',
              'new_api_calls':0,'independent_validation':False,'quota_last_checked_remaining':73}
    a.csvwrite(OUT/'metrics.csv',tables);a.csvwrite(OUT/'changed_examples.csv',details)
    a.csvwrite(OUT/'actions.csv',actions);a.csvwrite(OUT/'warnings.csv',alerts);a.csvwrite(OUT/'verification.csv',verification)
    manifest.extend({'path':str(p),'sha256':a.sha(p)} for p in [PLAN,Path(__file__),Path(m.__file__)])
    a.dump(OUT/'manifest.json',manifest);a.dump(OUT/'decision.json',decision)
    print(json.dumps(decision,indent=2))
    for r in tables:
        if r['task']=='ALL':print(r['group'],r['scenario'],r['candidate'],r['after_correct'],r['helped'],r['harmed'])

if __name__=='__main__':main()
