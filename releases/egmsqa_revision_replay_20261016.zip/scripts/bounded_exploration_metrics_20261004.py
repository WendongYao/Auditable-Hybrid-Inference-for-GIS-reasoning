"""Evaluation utilities; no candidate selection or network access."""
from collections import defaultdict
import analyze_gate_20261003 as g
import revise_results_20261001 as a
from revision_evidence_audit_20261004 import whitelist


def observable_inputs(dataset):
    # Whitelist excludes labels, buckets, task tolerances, source IDs and coordinates.
    return {i:whitelist(x) for i,x in dataset.items()}


def evaluate(dataset, evidence, candidates, group, original_gold=None):
    tables=[]; examples=[]
    for name, preds in candidates.items():
        assert set(preds)==set(evidence)==set(dataset)
        groups=defaultdict(list)
        for i,x in dataset.items():
            gold=original_gold[x['source_id']] if original_gold is not None else x
            b=g.correct(gold,evidence[i]); c=g.correct(gold,preds[i])
            changed=a.val(evidence[i])!=a.val(preds[i])
            row={'group':group,'candidate':name,'id':i,'source_id':x.get('source_id',i),
                 'task':x['task_name'],'scenario':x.get('scenario','unperturbed'),
                 'before':a.val(evidence[i]),'after':a.val(preds[i]),'gold':gold['answer'],
                 'before_correct':int(b),'after_correct':int(c),
                 'helped':int(not b and c),'harmed':int(b and not c),'changed':int(changed)}
            for t in [x['task_name'],'ALL']:
                groups[(row['scenario'],t)].append(row)
            if changed or b!=c:examples.append(row)
        for (scenario,task), rows in groups.items():
            n=len(rows);bc=sum(r['before_correct'] for r in rows);ac=sum(r['after_correct'] for r in rows)
            h=sum(r['helped'] for r in rows);d=sum(r['harmed'] for r in rows)
            ch=sum(r['changed'] for r in rows)
            exposed_correct=sum(r['changed'] and r['before_correct'] for r in rows)
            assert ac-bc==h-d
            tables.append({'group':group,'candidate':name,'scenario':scenario,'task':task,'n':n,
                'before_correct':bc,'after_correct':ac,'helped':h,'harmed':d,'net':h-d,
                'changed':ch,'changed_before_correct':exposed_correct,
                'harm_over_before_correct':d/bc if bc else None,
                'harm_over_changed_before_correct':d/exposed_correct if exposed_correct else None,
                'help_over_before_wrong':h/(n-bc) if bc<n else None,
                'delta_pp':100*(h-d)/n})
    return tables,examples


def load_sets():
    root=a.DATA
    dev=g.OUT/'dev';fixed=g.OUT/'metadata_repair/dev'
    matched=root/'revision_20261002_matched';noise=root/'revision_20261002_uncertainty'
    files={
        'gemini252': [dev/'dataset_fullprefix.jsonl',fixed/'predictions_E.jsonl',fixed/'predictions_H0.jsonl'],
        'gpt180': [matched/'dataset_fullprefix.jsonl',matched/'preds/Evidence_LLM.jsonl',matched/'preds/Hybrid_no_gate.jsonl'],
        'gpt_noise': [noise/'dataset.jsonl',noise/'preds/Evidence_LLM.jsonl',noise/'preds/Hybrid_no_gate.jsonl']}
    loaded={k:tuple(a.load(p) for p in ps) for k,ps in files.items()}
    manifest=[{'path':str(p),'sha256':a.sha(p)} for ps in files.values() for p in ps]
    return loaded,manifest
