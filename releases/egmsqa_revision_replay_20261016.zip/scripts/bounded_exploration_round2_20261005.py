"""Explicitly user-authorized second round, six frozen offline combinations."""
import copy,datetime,json
from pathlib import Path
from collections import defaultdict
import numpy as np
import bounded_exploration_round1_20261004 as b
import bounded_exploration_metrics_20261004 as m
import revise_results_20261001 as a
import analyze_gate_20261003 as g

OUT=a.DATA/'bounded_exploration_round2_20261005'
PLAN=a.ROOT.parent/'revision/15_round2_plan_20261005.md'
POLICIES={'S':{'S'},'B':{'B'},'S_F':{'S','F'},'B_F':{'B','F'},'S_B':{'S','B'},'S_B_F':{'S','B','F'}}

def amplitude(x):
    s=x['context']['series'];dates=s['t_iso'];y=s['d_mm']
    origin=datetime.date.fromisoformat(dates[0]); pairs=[((datetime.date.fromisoformat(d)-origin).days/365.25,v) for d,v in zip(dates,y) if b.finite(v)]
    if len(pairs)<6:return None
    tt=np.array([p[0] for p in pairs]);yy=np.array([p[1] for p in pairs])
    X=np.c_[np.sin(2*np.pi*tt),np.cos(2*np.pi*tt),np.ones(len(tt))]
    co,_,rank,_=np.linalg.lstsq(X,yy,rcond=None)
    return float(np.hypot(co[0],co[1])) if rank==3 else None

def propose(inputs,e,h):
    outputs={n:copy.deepcopy(e) for n in POLICIES};decisions=[];features=[]
    for i,x in inputs.items():
        ev=a.val(e[i]);hv=a.val(h[i]);t=x['task_name'];actions={};f={'id':i,'task':t,'candidate_date':None,'candidate_value':None,'amplitude':None,'rule_gap':None,'evidence_gap':None}
        if not b.valid(e[i]) and t.startswith(('B','C')) and b.valid(h[i]):actions['F']=(hv,'invalid_bc_rule_fallback')
        if t=='C2_step_mag' and b.valid(e[i]) and b.finite(ev):
            c=b.candidate(x)
            if c:
                f.update(candidate_date=c['date'],candidate_value=c['value'])
                if ev*c['value']<0 and round(abs(ev),1)==round(abs(c['value']),1):actions['S']=(-ev,'unique_boundary_rounded_absolute_magnitude_match_opposite_sign')
        if t=='B2_seasonality_amp' and b.valid(e[i]) and b.valid(h[i]) and b.finite(ev) and b.finite(hv) and ev>=0 and hv>=0:
            q=amplitude(x)
            if q is not None:
                f.update(amplitude=q,rule_gap=abs(hv-q),evidence_gap=abs(ev-q))
                if q>=.5 and abs(hv-q)<=.125+1e-9 and abs(ev-q)>.5+1e-9:actions['B']=(hv,'numeric_rule_matches_visible_fit_llm_disagrees')
        if t.startswith(('B2','C2')):features.append(f)
        for name,components in POLICIES.items():
            selected=[k for k in actions if k in components]
            assert len(selected)<=1,'Write scopes must be disjoint'
            if selected:
                k=selected[0];v,reason=actions[k];outputs[name][i].update(answer_parsed=v,parse_error=None)
                decisions.append({'candidate':name,'component':k,'id':i,'task':t,'before':ev,'after':v,'reason':reason})
    return outputs,decisions,features

def check_synthetic():
    # Sign repair from observed data, no gold and no paired C1 needed.
    x={'id':'test_C2_step_mag','task_name':'C2_step_mag','context':{'series':{'t_iso':['2020-01-01','2020-01-02','2020-01-03'],'d_mm':[0,-4,-4]},'static':{'rmse_mm':1}}}
    e={x['id']:{'id':x['id'],'task_name':x['task_name'],'answer_parsed':4.0,'parse_error':None}}
    h=copy.deepcopy(e);ps,_,_=propose({x['id']:x},e,h)
    assert a.val(ps['S'][x['id']])==-4 and a.val(ps['B'][x['id']])==4
    x['context']['series']['d_mm']=[0,-4,0]
    assert a.val(propose({x['id']:x},e,h)[0]['S'][x['id']])==4,'Tie must abstain'
    x['context']['series']['d_mm']=[0,None,-4]
    assert a.val(propose({x['id']:x},e,h)[0]['S'][x['id']])==4,'Cannot bridge missing'
    dates=[(datetime.date(2020,1,1)+datetime.timedelta(days=30*j)).isoformat() for j in range(24)]
    y=[2*np.sin(2*np.pi*30*j/365.25) for j in range(24)]
    x={'id':'test_B2_seasonality_amp','task_name':'B2_seasonality_amp','context':{'series':{'t_iso':dates,'d_mm':y},'static':{'rmse_mm':1}}}
    e={x['id']:{'id':x['id'],'task_name':x['task_name'],'answer_parsed':4.,'parse_error':None}};h=copy.deepcopy(e);h[x['id']]['answer_parsed']=2.
    assert abs(amplitude(x)-2)<1e-10
    assert a.val(propose({x['id']:x},e,h)[0]['B'][x['id']])==2
    e[x['id']]['answer_parsed']='none'
    assert a.val(propose({x['id']:x},e,h)[0]['B'][x['id']])=='none'

def main():
    check_synthetic()
    assert not OUT.exists(),'Preserve previous exploration'
    OUT.mkdir()
    a.dump(OUT/'freeze.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':a.sha(PLAN),
        'script_sha256':a.sha(Path(__file__)),'candidates':list(POLICIES),'round':2,'user_override_of_round1_stop':True,'weekly_remaining_before_round':71})
    sets,manifest=m.load_sets();metrics=[];examples=[];logs=[];features=[];supplement=[];locations=[];checks=[]
    for group,(data,oe,oh) in sets.items():
        print('Generating',group,flush=True)
        e={i:b.simple(p) for i,p in oe.items()};h={i:b.simple(p) for i,p in oh.items()};inp=m.observable_inputs(data)
        ps,log,feat=propose(inp,e,h)
        poison=copy.deepcopy(data)
        for x in poison.values():x.update(answer='POISON',bucket_label='POISON',answer_numeric=-999999,eval={'poison':True},meta={'poison':True})
        assert ps==propose(m.observable_inputs(poison),e,h)[0]
        idmap={i:f'anon_{j}' for j,i in enumerate(inp)}
        def anon(rows):return {idmap[i]:{**p,'id':idmap[i]} for i,p in rows.items()}
        ap=propose(anon(inp),anon(e),anon(h))[0]
        assert all(anon(p)==ap[n] for n,p in ps.items())
        for name,p in ps.items():
            assert all(a.val(p[i])==a.val(e[i]) for i in e if b.valid(e[i]) and (a.val(e[i])=='none' or e[i]['task_name'].startswith(('A','B1','C1'))))
            a.jsonlwrite(OUT/f'{group}/{name}.jsonl',p.values())
        ps['E']=e
        ps['F']=a.load(b.OUT/f'{group}/FALLBACK.jsonl')
        assert all(a.val(ps['F'][i])==(a.val(h[i]) if not b.valid(e[i]) and e[i]['task_name'].startswith(('B','C')) and b.valid(h[i]) else a.val(e[i])) for i in e)
        original=sets['gpt180'][0] if group=='gpt_noise' else None
        for baseline in ['E','F']:
            tb,ex=m.evaluate(data,ps[baseline],ps,group,original)
            for r in tb:r.update(baseline=baseline,relative_accuracy_change=r['net']/r['before_correct'] if r['before_correct'] else None)
            for r in ex:r['baseline']=baseline
            metrics.extend(tb);examples.extend(ex)
        for n,p in ps.items():
            bysc=defaultdict(list);byp=defaultdict(list)
            for i,x in data.items():
                gold=original[x['source_id']] if original else x;ok0=g.correct(gold,e[i]);ok1=g.correct(gold,p[i]);sc=x.get('scenario','unperturbed')
                r={'helped':int(not ok0 and ok1),'harmed':int(ok0 and not ok1),'both_correct':int(ok0 and ok1),'both_wrong':int(not ok0 and not ok1),
                   'before_invalid':int(not b.valid(e[i])),'after_invalid':int(not b.valid(p[i])),
                   'before_none':int(a.val(e[i])=='none'),'after_none':int(a.val(p[i])=='none'),
                   'changed':int(a.val(e[i])!=a.val(p[i]))}
                for t in [x['task_name'],'ALL']:bysc[(sc,t)].append(r)
                src=x.get('source_id',i);pid=src[:-(len(x['task_name'])+1)];byp[(sc,pid)].append(r)
            for (sc,t),rs in bysc.items():
                sums={k:sum(r[k] for r in rs) for k in rs[0]}
                supplement.append({'group':group,'candidate':n,'scenario':sc,'task':t,'n':len(rs),**sums,'harm_over_changed':sums['harmed']/sums['changed'] if sums['changed'] else None})
            for (sc,pid),rs in byp.items():
                hh=sum(r['helped'] for r in rs);dd=sum(r['harmed'] for r in rs)
                locations.append({'group':group,'candidate':n,'scenario':sc,'location':pid,'n':len(rs),'helped':hh,'harmed':dd,'net':hh-dd})
        logs.extend({**r,'group':group} for r in log);features.extend({**r,'group':group} for r in feat)
        checks.append({'group':group,'n':len(data),'gold_poison_invariant':True,'ID_renaming_invariant':True,'none_and_nontarget_preserved':True,'F_reproduced':True})
    decisions=[]
    for name in POLICIES:
        rows=[r for r in metrics if r['candidate']==name and r['baseline']=='E']
        gm=next(r for r in rows if r['group']=='gemini252' and r['task']=='ALL');gt=next(r for r in rows if r['group']=='gpt180' and r['task']=='ALL')
        gf=next(r for r in metrics if r['candidate']==name and r['baseline']=='F' and r['group']=='gemini252' and r['task']=='ALL')
        nplace=sum(r['helped']>0 for r in locations if r['candidate']==name and r['group']=='gemini252')
        conditions={'gemini_net_ge3':gm['net']>=3,'gemini_harm_le1':gm['harmed']<=1,'gemini_over_F_ge2':gf['net']>=2,'helped_locations_ge2':nplace>=2,
            'all_clean_tasks_nonnegative':all(r['net']>=0 for r in rows if r['group'] in ['gemini252','gpt180']),
            'gpt_harm_le1':gt['harmed']<=1,'noise_scenarios_nonnegative':all(r['net']>=0 for r in rows if r['group']=='gpt_noise' and r['task']=='ALL')}
        decisions.append({'candidate':name,**conditions,'passed':all(conditions.values())})
    for file,rows in [('metrics',metrics),('changed_examples',examples),('actions',logs),('features',features),('supplementary_metrics',supplement),('by_location',locations),('verification',checks),('decision',decisions)]:a.csvwrite(OUT/f'{file}.csv',rows)
    manifest.extend({'path':str(p),'sha256':a.sha(p)} for p in [PLAN,Path(__file__),Path(b.__file__),Path(m.__file__),Path(g.__file__),Path(g.score.__file__)])
    a.dump(OUT/'manifest.json',manifest)
    passed=[r['candidate'] for r in decisions if r['passed']]
    a.dump(OUT/'status.json',{'status':'completed_candidate_found' if passed else 'completed_no_qualifying_candidate','passed':passed,'new_api_calls':0,'independent_validation':False,'round3_authorized':False})
    print(json.dumps(decisions,indent=2))
    for r in metrics:
        if r['task']=='ALL' and r['baseline']=='E':print(r['group'],r['scenario'],r['candidate'],r['after_correct'],r['helped'],r['harmed'])

if __name__=='__main__':main()
