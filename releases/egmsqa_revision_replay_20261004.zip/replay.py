"""Offline replay; no provider calls or environment credentials are read."""
from pathlib import Path
import argparse,csv,hashlib,json,sys,subprocess
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import revise_results_20261001 as a
from revision_matched_protocol_20261002 import local_pipeline,compose,make_prompt
from revision_window_audit_20261002 import records

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mode',choices=['cases','all'],default='cases')
    args=ap.parse_args()
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    for name,digest in manifest['files'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,('hash mismatch',name)
    data=ROOT/'egmsqa/out_qa_v5_8';m=data/'revision_20261002_matched';out=ROOT/'replay_output';out.mkdir(exist_ok=True)
    allrows=list(records(m/'dataset_fullprefix.jsonl'))
    cases=[json.loads(p.read_text()) for p in sorted((m/'replay_cases').glob('*.json')) if not p.stem.endswith('_antecedent')]
    keys={(t['source']['tile_id'],t['source']['pid']) for t in cases}
    rows=allrows if args.mode=='all' else [x for x in allrows if (x['tile_id'],x['pid']) in keys]
    a.jsonlwrite(out/'dataset.jsonl',rows)
    local_pipeline(out/'dataset.jsonl',out/'rules')
    evidence=a.load(m/'preds/Evidence_LLM.jsonl',True)
    base={x['id']:evidence[x['id']] for x in rows}
    rules,full=compose(base,out/'rules')
    expected=a.load(m/'preds/Hybrid_full.jsonl',True)
    for i,p in full.items():assert p['answer_parsed']==expected[i]['answer_parsed'],('answer mismatch',i)
    for t in cases:
        x=t['source'];prompt=make_prompt(x,True)
        assert hashlib.sha256(prompt.encode()).hexdigest()==t['prompt_sha256']
        assert rules[x['id']]['answer_parsed']==t['after_rules']['answer_parsed']
        assert rules[x['id']].get('debug')==t['after_rules'].get('debug'), ('rule evidence mismatch',x['id'])
        print(x['id'],t['LLM_answer']['answer_parsed'],'->',rules[x['id']]['answer_parsed'],'->',full[x['id']]['answer_parsed'])
    result={'mode':args.mode,'hashes_verified':len(manifest['files']),'recomputed_qa':len(rows),'cases_verified':len(cases),'api_calls':0}
    if args.mode=='all':
        targets=[m/'metrics.csv',m/'paired_differences.csv',data/'revision_20261002_uncertainty/overview.csv',data/'revision_20261002_uncertainty/task_sensitivity.csv',data/'revision_20261002_uncertainty/conditional_distributions.csv']
        before={p:list(csv.DictReader(p.open(encoding='utf-8-sig'))) for p in targets}
        for script in ['analyze_revision_matched_20261002.py','analyze_revision_uncertainty_20261002.py']:
            with (out/(script+'.log')).open('w') as log:subprocess.run([sys.executable,str(ROOT/'scripts'/script)],stdout=log,stderr=subprocess.STDOUT,check=True)
        for p,old in before.items():
            new=list(csv.DictReader(p.open(encoding='utf-8-sig')))
            assert len(new)==len(old)
            for aa,bb in zip(old,new):
                assert aa.keys()==bb.keys()
                for k in aa:
                    if aa[k]==bb[k]:continue
                    try:assert abs(float(aa[k])-float(bb[k]))<1e-10
                    except (ValueError,AssertionError):raise AssertionError(('table mismatch',str(p),k,aa[k],bb[k]))
        result['tables_verified']=[str(p.relative_to(ROOT)) for p in targets]
    (out/'verification.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
