"""Offline reference isolation, paired interventions, and cached sensitivity replay."""
import copy,json,hashlib,inspect
from collections import defaultdict
from pathlib import Path
import numpy as np
import analyze_gate_20261003 as g
import offline_gate_round2_20261004 as sweep
import analyze_revision_uncertainty_20261002 as u
import revise_results_20261001 as a
from revision_window_audit_20261002 import records,DATA,ROOT

OUT=DATA/'revision_evidence_audit_20261004'

def fallback(e,h):
    # Frozen ROUTE_BC definition. No gold or per-ID conditions.
    return {i:copy.deepcopy(e[i] if p['task_name'].startswith(('B','C')) and sweep.valid(e[i]) and e[i]['answer_parsed']!=p.get('answer_parsed') else p) for i,p in h.items()}

def whitelist(x):
    return {'id':x['id'],'task_name':x['task_name'],'context':{'series':{k:copy.deepcopy(x['context']['series'][k]) for k in ['t_iso','d_mm']},'static':{'rmse_mm':x['context']['static']['rmse_mm']}}}

def transition(gold,before,after,label):
    out=[]
    for task in a.TASKS+['ALL']:
        ids=[i for i,x in gold.items() if task=='ALL' or x['task_name']==task]
        b=np.array([g.correct(gold[i],before[i]) for i in ids]);c=np.array([g.correct(gold[i],after[i]) for i in ids])
        out.append({'transition':label,'task':task,'n':len(ids),'before_correct':int(b.sum()),'after_correct':int(c.sum()),'helped':int((~b&c).sum()),'harmed':int((b&~c).sum()),'both_correct':int((b&c).sum()),'both_wrong':int((~b&~c).sum()),'changed_answer':sum(before[i].get('answer_parsed')!=after[i].get('answer_parsed') for i in ids),'before_invalid':sum(not sweep.valid(before[i]) for i in ids),'after_invalid':sum(not sweep.valid(after[i]) for i in ids),'before_none':sum(before[i].get('answer_parsed')=='none' for i in ids),'after_none':sum(after[i].get('answer_parsed')=='none' for i in ids)})
    return out

def main():
    OUT.mkdir(exist_ok=True)
    dev=g.OUT/'dev';fixed=g.OUT/'metadata_repair/dev'
    gold=a.load(dev/'dataset_fullprefix.jsonl'); clean=[whitelist(x) for x in gold.values()]
    ref=g.operational_reference(clean)
    altered=copy.deepcopy(list(gold.values()))
    for x in altered:x.update(answer='POISON',answer_numeric=-987654321,meta={'gold':'POISON'},bucket_label='POISON',eval={'POISON':True})
    assert ref==g.operational_reference(altered)==g.operational_reference(gold.values())
    req={r['request_key']:r for r in records(dev/'requests_frozen.jsonl')}
    from revision_matched_protocol_20261002 import make_prompt
    for x in gold.values():
        for branch in ['raw','evidence']:
            assert make_prompt(x,branch=='evidence')==req[branch+'|'+x['id']]['prompt']
        assert x['meta']['rmse_mm']==x['context']['static']['rmse_mm']
    # Serializing only the allowlist is an executable data boundary for the reference.
    a.jsonlwrite(OUT/'reference_inputs_allowlist.jsonl',clean)
    a.jsonlwrite(OUT/'reference_predictions.jsonl',ref.values())
    systems={k:a.load(fixed/f'predictions_{k}.jsonl') for k in ['R','E','H0']}
    systems['OLD']=a.apply_gate(systems['H0']);systems['FALLBACK']=fallback(systems['E'],systems['H0'])
    assert systems['FALLBACK']==a.load(sweep.OUT/'predictions_ROUTE_BC.jsonl')
    pairs=[('R','E'),('E','H0'),('H0','OLD'),('E','FALLBACK')]
    table=[]
    for b,c in pairs:table+=transition(gold,systems[b],systems[c],b+'->'+c)
    a.csvwrite(OUT/'paired_transitions.csv',table)
    details=[]
    for b,c in pairs:
        for i,x in gold.items():
            details.append({'transition':b+'->'+c,'id':i,'task':x['task_name'],'before':systems[b][i].get('answer_parsed'),'after':systems[c][i].get('answer_parsed'),'before_correct':int(g.correct(x,systems[b][i])),'after_correct':int(g.correct(x,systems[c][i]))})
    a.csvwrite(OUT/'paired_examples.csv',details)
    # Paired bootstrap by entire location (6 dependent task answers).
    bids=sorted({g.base_id(x) for x in gold.values()});rng=np.random.default_rng(20261004);boot=[]
    for b,c in pairs:
        dif=np.array([sum(int(g.correct(x,systems[c][i]))-int(g.correct(x,systems[b][i])) for i,x in gold.items() if g.base_id(x)==bid)/6 for bid in bids])
        draws=rng.choice(dif,(10000,len(bids)),replace=True).mean(1)
        boot.append({'transition':b+'->'+c,'locations':len(bids),'delta_pp':100*dif.mean(),'bootstrap_lo_pp':100*np.quantile(draws,.025),'bootstrap_hi_pp':100*np.quantile(draws,.975),'scope':'paired location bootstrap, development-set descriptive sampling only; not selection-adjusted or spatially independent validation'})
    a.csvwrite(OUT/'paired_location_bootstrap.csv',boot)
    # Cached GPT study: separate protocol and sample, never a model ranking.
    matched=DATA/'revision_20261002_matched';noise=DATA/'revision_20261002_uncertainty'
    mg=a.load(matched/'dataset_fullprefix.jsonl');me=a.load(matched/'preds/Evidence_LLM.jsonl',True);mh=a.load(matched/'preds/Hybrid_no_gate.jsonl',True)
    mf=fallback(me,mh);a.csvwrite(OUT/'gpt_retrospective_fallback.csv',transition(mg,me,mf,'E->FALLBACK'))
    dataset=a.load(noise/'dataset.jsonl');ne=a.load(noise/'preds/Evidence_LLM.jsonl',True);nh=a.load(noise/'preds/Hybrid_no_gate.jsonl',True);nf=fallback(ne,nh)
    rows=[]
    for name,ps,control in [('E',ne,me),('FALLBACK',nf,mf)]:
        a.jsonlwrite(OUT/f'uncertainty_{name}.jsonl',ps.values())
        for i,x in dataset.items():
            p=ps[i];cp=control[x['source_id']];task=x['task_name'];v=u.numeric(p.get('answer_parsed'),task);cv=u.numeric(cp.get('answer_parsed'),task)
            k=u.kind(p,task);ck=u.kind(cp,task)
            rows.append({'system':name,'id':i,'source_id':x['source_id'],'scenario':x['scenario'],'replicate':x['replicate'],'task':task,'answer':p.get('answer_parsed'),'control':cp.get('answer_parsed'),'kind':k,'control_kind':ck,'changed':int(p.get('answer_parsed')!=cp.get('answer_parsed')),'kind_changed':int(k!=ck),'none':int(k=='none'),'invalid':int(k=='invalid'),'correct':int(g.correct(mg[x['source_id']],p)),'numeric':v if k!='invalid' else None,'abs_delta':abs(v-cv) if v is not None and cv is not None and k!='invalid' and ck!='invalid' else None,'sign_flip':int(task=='C2_step_mag' and {k,ck}=={'negative','positive'})})
    a.csvwrite(OUT/'sensitivity_examples.csv',rows)
    groups=defaultdict(list);dist=defaultdict(list)
    for r in rows:
        groups[(r['system'],r['scenario'],r['task'])].append(r);groups[(r['system'],r['scenario'],'ALL')].append(r)
        dist[(r['system'],r['scenario'],r['task'],r['source_id'])].append(r)
    summary=[]
    for (name,sc,task),rs in groups.items():
        ds=[r['abs_delta'] for r in rs if r['abs_delta'] is not None]
        summary.append({'system':name,'scenario':sc,'task':task,'n':len(rs),'source_qa_n':len({r['source_id'] for r in rs}),**{k:sum(r[k] for r in rs) for k in ['changed','kind_changed','none','invalid','correct','sign_flip']},'numeric_pairs':len(ds),'median_abs_delta':float(np.median(ds)) if ds and task!='ALL' else None})
    a.csvwrite(OUT/'sensitivity_summary.csv',summary)
    distributions=[]
    for (name,sc,task,src),rs in dist.items():
        vs=[r['numeric'] for r in rs if r['numeric'] is not None]
        distributions.append({'system':name,'scenario':sc,'task':task,'source_id':src,'n':len(rs),'numeric_n':len(vs),'none_n':sum(r['none'] for r in rs),'invalid_n':sum(r['invalid'] for r in rs),'q025':float(np.quantile(vs,.025)) if vs else None,'median':float(np.median(vs)) if vs else None,'q975':float(np.quantile(vs,.975)) if vs else None,'unit':{'A2_trend_v':'mm/year','B2_seasonality_amp':'mm','C2_step_mag':'mm','C1_step_time':'ordinal calendar days'}.get(task,'categorical')})
    a.csvwrite(OUT/'sensitivity_distributions.csv',distributions)
    report={'reference_correct':sum(g.correct(x,ref[i]) for i,x in gold.items()),'reference_n':len(gold),'gold_deletion_and_poison_invariant':True,'all_504_prompts_reproduced':True,'rmse_paths_equal':True,'reference_input_allowlist':['id (output join only)','task_name','context.series.t_iso','context.series.d_mm','context.static.rmse_mm'],'limitation':'RMSE is supplied product metadata; prefix-only estimation and physical calibration not established. No independent geophysical truth or unseen test claim.','new_api_calls':0,'script_sha256':a.sha(Path(__file__)),'reference_function_sha256':hashlib.sha256(inspect.getsource(g.operational_reference).encode()).hexdigest()}
    a.dump(OUT/'verification.json',report)
    print(json.dumps(report,indent=2));print(json.dumps([r for r in table if r['task']=='ALL'],indent=2));print(json.dumps([r for r in summary if r['task']=='ALL'],indent=2))

if __name__=='__main__':main()
