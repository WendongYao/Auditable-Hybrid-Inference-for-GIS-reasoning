"""Finite local development sweep; no network, no validation-set reads."""
import copy
import json
from pathlib import Path
from collections import Counter
import numpy as np
import analyze_gate_20261003 as m
import revise_results_20261001 as a
from revision_window_audit_20261002 import records,ROOT

OUT=m.OUT/'offline_round2_dev_20261004'

def valid(p):return not p.get('parse_error') and p.get('answer_parsed') is not None

def propose(h0,e,stability):
    v={'H0':copy.deepcopy(h0),'OLD':a.apply_gate(h0)};decisions=[]
    for policy in ['C2_ONLY','C2_DUAL_NONE','C2_WEAK','ROUTE_B','ROUTE_BC']:
        pred=copy.deepcopy(h0)
        for i,p in pred.items():
            t=p['task_name'];reason='keep_hybrid'
            routed=t.startswith('B') if policy=='ROUTE_B' else t.startswith(('B','C')) if policy=='ROUTE_BC' else False
            if routed and valid(e[i]) and e[i]['answer_parsed']!=p.get('answer_parsed'):
                pred[i]=copy.deepcopy(e[i]);reason='protect_valid_llm_from_disagreeing_rule'
            elif routed and not valid(e[i]) and valid(p):reason='fallback_to_rule_for_invalid_llm'
            if policy!='ROUTE_BC' and t=='C2_step_mag' and m.numeric(p.get('answer_parsed')):
                upstream=h0[m.base_id(p)+'_C1_step_time']
                veto=valid(upstream) and upstream['answer_parsed']=='none'
                if policy=='C2_DUAL_NONE':veto=veto and valid(e[i]) and e[i]['answer_parsed']=='none'
                if policy=='C2_WEAK':veto=veto and stability.get(i,{}).get('status')=='available' and stability[i]['S']<.60
                if veto:
                    pred[i].update(answer_parsed='none',answer_numeric=None);reason='c2_veto_'+policy
            decisions.append({'policy':policy,'id':i,'reason':reason,'before':h0[i].get('answer_parsed'),'after':pred[i].get('answer_parsed')})
        v[policy]=pred
    return v,decisions

def main():
    assert not OUT.exists(),'Preserve completed sweep; do not overwrite'
    dev=m.OUT/'dev';fixed=m.OUT/'metadata_repair/dev'
    h0=a.load(fixed/'predictions_H0.jsonl');e=a.load(fixed/'predictions_E.jsonl');r=a.load(fixed/'predictions_R.jsonl')
    stability=json.loads((dev/'stability.json').read_text())
    variants,decisions=propose(h0,e,stability)
    variants.update(R=r,E=e,label_definition_reference=m.operational_reference(records(dev/'inputs_only.jsonl')))
    # Prediction selection above uses no gold or validation data. Score only afterwards.
    gold=a.load(dev/'dataset_fullprefix.jsonl');folds=json.loads((dev/'fold_assignments.json').read_text())
    assert all(set(p)==set(gold) for p in variants.values())
    scores={name:{i:int(m.correct(g,p[i])) for i,g in gold.items()} for name,p in variants.items()}
    summary=[];tasks=[];actions=[]
    for name,p in variants.items():
        row={'variant':name,'correct':sum(scores[name].values()),'n':len(gold),'accuracy':sum(scores[name].values())/len(gold)}
        for baseline in ['H0','E']:
            dif={i:scores[name][i]-scores[baseline][i] for i in gold}
            row.update({f'helped_vs_{baseline}':sum(d>0 for d in dif.values()),f'harmed_vs_{baseline}':sum(d<0 for d in dif.values()),f'net_vs_{baseline}':sum(dif.values())})
        for fold in range(3):row[f'fold{fold}_net_vs_E']=sum(scores[name][i]-scores['E'][i] for i,g in gold.items() if folds[m.base_id(g)]==fold)
        summary.append(row)
        for task in a.TASKS:
            ids=[i for i,g in gold.items() if g['task_name']==task]
            tasks.append({'variant':name,'task':task,'n':len(ids),'correct':sum(scores[name][i] for i in ids)})
        for i,g in gold.items():
            if p[i].get('answer_parsed')!=h0[i].get('answer_parsed'):
                actions.append({'variant':name,'id':i,'task':g['task_name'],'H0':h0[i].get('answer_parsed'),
                    'E':e[i].get('answer_parsed'),'after':p[i].get('answer_parsed'),'gold':g['answer'],
                    'delta_vs_H0':scores[name][i]-scores['H0'][i],'delta_vs_E':scores[name][i]-scores['E'][i]})
    OUT.mkdir()
    a.csvwrite(OUT/'summary.csv',summary);a.csvwrite(OUT/'task_metrics.csv',tasks);a.csvwrite(OUT/'actions.csv',actions)
    a.jsonlwrite(OUT/'decisions.jsonl',decisions)
    for name,p in variants.items():a.jsonlwrite(OUT/f'predictions_{name}.jsonl',p.values())
    a.dump(OUT/'manifest.json',{'scope':'252 QA development only; 504 saved model calls; no validation reads',
        'new_model_calls':0,'candidate_selection_uses_gold':False,'scoring_uses_gold':True,
        'script_sha256':a.sha(Path(__file__)),'plan_sha256':a.sha(ROOT.parent/'revision/GATE_LOCAL_ROUND2_PLAN_20261004.md'),
        'inputs_sha256':{str(p):a.sha(p) for p in [fixed/'predictions_H0.jsonl',fixed/'predictions_E.jsonl',dev/'stability.json',dev/'dataset_fullprefix.jsonl']}})
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
