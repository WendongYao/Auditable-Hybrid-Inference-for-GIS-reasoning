"""Build explicitly selected success/failure/gate audit cases from actual matched calls."""
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from prepare_revision_matched_subset_20261002 import OUT
from revision_window_audit_20261002 import records, ROOT
import revise_results_20261001 as a
import score

def main():
    traces=sorted(records(OUT/'audit_traces.jsonl'),key=lambda x:x['id'])
    predicates={
        'rule_corrects_error':lambda t:t['rule_changed'] and not score.score_one(t['source'],t['LLM_answer'])[0] and score.score_one(t['source'],t['after_rules'])[0],
        'rule_introduces_error':lambda t:t['rule_changed'] and score.score_one(t['source'],t['LLM_answer'])[0] and not score.score_one(t['source'],t['after_rules'])[0],
        'gate_changes_answer':lambda t:t['gate_changed']}
    chosen={name:next((t for t in traces if p(t)),None) for name,p in predicates.items()}
    negative=next(x for x in records(OUT/'dataset_fullprefix.jsonl') if x['task_name']=='C2_step_mag' and str(x['answer'])!='none' and float(x['answer'])<0)
    chosen['seed_selected_negative_step']=next(t for t in traces if t['id']==negative['id'])
    folder=OUT/'replay_cases';folder.mkdir(exist_ok=True)
    requests={r['request_key']:r for r in records(OUT/'requests_frozen.jsonl')}
    texts=['# Real replay cases','', 'Post-hoc illustrative selection: first lexicographic ID satisfying each documented success/failure/gate criterion. The fourth case is the first negative-step series in the outcome-blind frozen selection order. These are explanatory cases, not a representative performance sample.','']
    for name,t in chosen.items():
        if t is None:texts.extend([f'## {name}','No qualifying case.','']);continue
        a.dump(folder/f'{name}.json',t)
        prompt=requests['evidence|'+t['id']]['prompt']
        (folder/f'{name}_prompt.txt').write_text(prompt,encoding='utf8')
        x=t['source'];s=x['context']['series']
        a.csvwrite(folder/f'{name}_series.csv',[{'date':d,'displacement_mm':v} for d,v in zip(s['t_iso'],s['d_mm'])])
        original=''.join(c.get('text','') for o in t['LLM_raw_response'].get('output',[]) for c in o.get('content',[]) if c.get('type')=='output_text')
        texts.extend([f'## {name}',f"ID: `{t['id']}`",'',f"Original label: `{x['answer']}`; LLM response: `{original}`.",
                      f"After fixed rules: `{t['after_rules']['answer_parsed']}`; after gate: `{t['after_gate']['answer_parsed']}`.",
                      f"Correctness (operational weak label): LLM={score.score_one(x,t['LLM_answer'])[0]}, rules={score.score_one(x,t['after_rules'])[0]}, gate={score.score_one(x,t['after_gate'])[0]}.",
                      f"Prompt hash: `{t['prompt_sha256']}`. Full observed series, prompt and response/stages are stored beside this report.",''])
        if t['gate_changed']:
            base=t['id'][:-(len(x['task_name'])+1)]
            pairtask='C1_step_time' if x['task_name']=='C2_step_mag' else 'B1_seasonality_present'
            pair=next(z for z in traces if z['id']==base+'_'+pairtask)
            texts.extend([f"Gate antecedent {pairtask}: `{pair['after_rules']['answer_parsed']}`. The two tasks share the same observation input.",''])
            a.dump(folder/f'{name}_antecedent.json',pair)
    (folder/'README.md').write_text('\n'.join(texts),encoding='utf8')
    metrics=list(csv.DictReader((OUT/'metrics.csv').open(encoding='utf-8-sig')))
    fig,ax=plt.subplots(figsize=(8,4.4))
    labels=['Raw LLM','Evidence LLM','Hybrid\n(no gate)','Hybrid\n(full)','Deterministic\n(same tools)']
    vals=[100*float(x['macro']) for x in metrics]
    bars=ax.bar(labels,vals,color=['#8798a5','#5685ac','#39918c','#226a65','#bd8b3e'])
    ax.bar_label(bars,fmt='%.2f',padding=4,fontsize=10)
    ax.set(ylim=(0,100),ylabel='Accuracy (%)',title='Matched full-prefix comparison: 30 series, 180 questions')
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    fig.text(.5,.01,'Operational weak-label agreement; stratified development subset. Label-generator replay: 100% by construction.',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.04,1,1))
    dest=ROOT.parent/'manuscript/generated_results_20261002';dest.mkdir(exist_ok=True)
    fig.savefig(dest/'matched_fullprefix_accuracy.png',dpi=220);fig.savefig(dest/'matched_fullprefix_accuracy.pdf');plt.close(fig)
    print('\n'.join(texts))

if __name__=='__main__':main()
