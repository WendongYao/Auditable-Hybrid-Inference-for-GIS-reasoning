from pathlib import Path
import csv,hashlib,json,sys,subprocess
root=Path(__file__).resolve().parent
for p,h in json.loads((root/'MANIFEST.json').read_text())['files'].items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
sys.path.insert(0,str(root/'scripts'))
import compare_simple_controls_20261005 as c
import bounded_exploration_metrics_20261004 as m
import bounded_exploration_round1_20261004 as b
import revise_results_20261001 as a
sets,_=m.load_sets()
for name,folder in [('prospective360','prospective_frozen_bf_v2_20261005'),('cached504','frozen_validation_20261005')]:
    p=a.DATA/folder;data=p/'dataset_fullprefix.jsonl'
    if not data.exists():data=a.DATA/'revision_gate_20261003/validation/dataset_fullprefix.jsonl'
    sets[name]=tuple(a.load(f) for f in [data,p/'predictions_E.jsonl',p/'predictions_H0.jsonl'])
metrics=list(csv.DictReader((a.DATA/'simple_controls_20261005/metrics.csv').open(encoding='utf-8-sig')))
n=0
for group,(ds,e,h) in sets.items():
    e={i:b.simple(p) for i,p in e.items()};h={i:b.simple(p) for i,p in h.items()}
    ps=c.policies(m.observable_inputs(ds),e,h)
    for name,pred in ps.items():
        saved=a.load(a.DATA/'simple_controls_20261005'/group/f'{name}.jsonl')
        assert pred==saved,(group,name)
    for base in ['E','BF']:
        rows,_=m.evaluate(ds,ps[base],ps,group,sets['gpt180'][0] if group=='gpt_noise' else None)
        for r in rows:
            z=next(x for x in metrics if all(x[k]==str(r[k]) for k in ['group','candidate','scenario','task']) and x['baseline']==base)
            for k in ['n','before_correct','after_correct','helped','harmed','changed']:assert int(z[k])==r[k],(group,k)
    n+=len(ds)
for script,folder,files in [('audit_limited_intervention_20261005.py','limited_intervention_audit_20261005',['replay_checks.csv']),('calendar_audit_20261005.py','calendar_audit_20261005',['summary.csv','details.csv'])]:
    paths=[a.DATA/folder/f for f in files];before=[p.read_bytes() for p in paths]
    subprocess.run([sys.executable,str(root/'scripts'/script)],check=True)
    assert all(p.read_bytes()==v for p,v in zip(paths,before)),script
print('PASS October 5 extension',n,'questions across saved settings; all simple-control predictions and metrics, 360 condition checks, and C1 calendar tables; zero API calls')
