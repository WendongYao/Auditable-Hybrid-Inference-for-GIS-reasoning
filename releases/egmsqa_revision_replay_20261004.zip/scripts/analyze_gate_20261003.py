"""Frozen deterministic gates, paired scoring and auditable selection; no network."""
import argparse
import copy
import hashlib
import json
import shutil
import datetime
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from revision_window_audit_20261002 import DATA, ROOT, records
from revision_matched_protocol_20261002 import compose,local_pipeline
from render_prompt_routeA_a3 import render_prompt_routeA_a3
import predict_c2_from_routeA_a3_prompt as c2
import revise_results_20261001 as a
import score

OUT=DATA/'revision_gate_20261003'
POLICIES=['G0','G1','G2','G3-0.60','G3-0.80','G3-0.90']
def numeric(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and np.isfinite(v)
def correct(g,p):return False if p.get('parse_error') else score.score_one(g,p,c1_policy='acquisition_index_v2')[0]
def base_id(x):return x['id'][:-(len(x['task_name'])+1)]

def operational_reference(xs):
    """Explicit label-definition calculator; not independent event ground truth."""
    out={}
    for x in xs:
        s=x['context']['series'];dates=s['t_iso'];y=np.array([np.nan if v is None else v for v in s['d_mm']])
        t=(pd.to_datetime(dates)-pd.to_datetime(dates[0])).days.to_numpy()/365.25;valid=np.isfinite(y)
        slope=np.linalg.lstsq(np.c_[t[valid],np.ones(valid.sum())],y[valid],rcond=None)[0][0]
        ab=np.linalg.lstsq(np.c_[np.sin(2*np.pi*t[valid]),np.cos(2*np.pi*t[valid]),np.ones(valid.sum())],y[valid],rcond=None)[0]
        amp=float(np.hypot(ab[0],ab[1]));diff=np.diff(y);finite=np.isfinite(diff)
        cdate='none';mag='none'
        if finite.any():
            k=int(np.argmax(np.where(finite,np.abs(diff),-np.inf)))
            if abs(diff[k])>=max(.5,3*x['context']['static']['rmse_mm']):cdate=dates[k+1].replace('-','');mag=round(float(diff[k]),1)
        answer={'A1_trend_dir':'uplifting' if slope>=.2 else ('subsiding' if slope<=-.2 else 'stable'),
            'A2_trend_v':round(float(slope),1),'B1_seasonality_present':'seasonal' if amp>=.5 else 'nonseasonal',
            'B2_seasonality_amp':round(amp,1) if amp>=.5 else 'none','C1_step_time':cdate,'C2_step_mag':mag}[x['task_name']]
        out[x['id']]={'id':x['id'],'task_name':x['task_name'],'answer_parsed':answer,'parse_error':None}
    return out

def predict_candidate(x):
    prompt=render_prompt_routeA_a3(x,c2_semantics='signed_delta')
    rmse=c2.parse_rmse_mm(prompt)
    if rmse is None or rmse<=0:rmse=1.
    cand=c2.parse_step_candidates(prompt)
    if not cand:return None
    best,debug=c2.pick_best_candidate(candidates=cand,rmse_mm=rmse,window_pts=c2.parse_window_points(prompt),
        anchor_pts=c2.parse_anchor_points(prompt),use_abs_delta=True,mag_thr=2.7,snr_thr=2.2,persist_frac_thr=.8,
        min_post_points=5,support_gap_max=.8,persist_frac_soft_min=.55,pf_override_snr_margin=.5,pf_override_mag_margin=.5)
    if best is None:return None
    return {'value':c2.answer_from_candidate(best,True,'signed_delta'),'date':best.cand.step_iso,'rank':best.cand.rank}

def stability(split):
    directory=OUT/split; path=directory/'stability.json'
    if path.exists():return json.loads(path.read_text())
    rule=a.load(directory/'rules/c2.jsonl');result={}; draws=[]
    for x in records(directory/'inputs_only.jsonl'):
        if x['task_name']!='C2_step_mag':continue
        p=rule[x['id']]; value=p['answer_parsed']
        if not numeric(value):
            result[x['id']]={'status':'not_numeric'};continue
        original=predict_candidate(x)
        assert original is not None and abs(original['value']-value)<1e-9,('rule reproduction mismatch',x['id'])
        rmse=x['context']['static'].get('rmse_mm')
        if not numeric(rmse) or rmse<=0:
            result[x['id']]={'status':'unavailable'};continue
        s=x['context']['series']; dates=s['t_iso'];y=np.array([np.nan if z is None else z for z in s['d_mm']],dtype=float)
        days=(pd.to_datetime(dates)-pd.to_datetime(dates[0])).days.to_numpy(dtype=float)
        cov=np.exp(-np.abs(days[:,None]-days[None,:])/30.)
        chol=np.linalg.cholesky(cov+1e-12*np.eye(len(y)))
        seed=int(hashlib.sha256(('20261003|'+x['id']).encode()).hexdigest()[:16],16)
        rng=np.random.default_rng(seed)
        noises={'iid':rng.normal(size=(20,len(y)))*.5*rmse,'correlated':(rng.normal(size=(20,len(y)))@chol.T)*.5*rmse}
        rates={}
        for name,noise in noises.items():
            hits=0
            for j,pert in enumerate(noise):
                z=copy.deepcopy(x); z['context']['series']['d_mm']=[None if not np.isfinite(v) else float(v) for v in y+pert]
                q=predict_candidate(z)
                ok=bool(q and np.sign(q['value'])==np.sign(value) and abs(dates.index(q['date'])-dates.index(original['date']))<=1
                    and abs(q['value']-value)<=max(.5,.25*abs(value)))
                hits+=int(ok);draws.append({'id':x['id'],'noise':name,'replicate':j,'candidate':q,'stable':ok,'seed':seed})
            rates[name]=hits/20
        result[x['id']]={'status':'available','S':min(rates.values()),'rates':rates,'original':original,'seed':seed}
    a.dump(path,result);a.jsonlwrite(directory/'stability_draws.jsonl',draws)
    return result

def gated(h0,policy,rules,stab):
    if policy=='G1':return a.apply_gate(h0)
    pred=copy.deepcopy(h0)
    if policy=='G0':return pred
    for i,p in pred.items():
        t=p['task_name'];bid=base_id(p)
        if t=='B2_seasonality_amp':
            upstream=rules['b1'][bid+'_B1_seasonality_present']
            veto=not upstream.get('parse_error') and upstream.get('answer_parsed')=='nonseasonal'
        elif t=='C2_step_mag':
            upstream=rules['c1'][bid+'_C1_step_time']
            veto=bool(upstream.get('use_alt')) and not upstream.get('parse_error')
            if veto and numeric(p.get('answer_parsed')) and policy.startswith('G3'):
                feature=stab.get(i,{'status':'unavailable'})
                if feature['status']=='unavailable' or feature.get('S',-1)>=float(policy.split('-')[1]):veto=False
        else:continue
        if veto and numeric(p.get('answer_parsed')):
            p.update(answer_parsed='none',answer_numeric=None,gate_applied=policy)
    return pred

def load_llm(directory):
    variants={'R':{},'E':{}}
    for path in sorted((directory/'api').glob('*.json')):
        r=json.loads(path.read_text())
        if 'response' not in r or 'candidates' not in r['response']:continue
        p={k:r.get(k) for k in ['id','task_name','answer_parsed','parse_error']}
        p['answer_numeric']=p['answer_parsed'] if numeric(p['answer_parsed']) else None
        branch='R' if r['branch']=='raw' else 'E'
        assert p['id'] not in variants[branch]
        variants[branch][p['id']]=p
    return variants

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--split',choices=['dev','validation'],required=True);ap.add_argument('--features-only',action='store_true')
    args=ap.parse_args();d=OUT/args.split
    if args.split=='validation':assert (OUT/'FREEZE.json').exists()
    if not (d/'rules/c2.jsonl').exists():local_pipeline(d/'inputs_only.jsonl',d/'rules')
    stab=stability(args.split)
    if args.features_only:print('Stability features ready',Counter(x['status'] for x in stab.values()),flush=True);return
    gold=a.load(d/'dataset_fullprefix.jsonl');variants=load_llm(d)
    assert all(set(p)==set(gold) for p in variants.values()),'Incomplete API results'
    variants['label_definition_reference']=operational_reference(records(d/'inputs_only.jsonl'))
    rules={name:a.load(d/f'rules/{name}.jsonl') for name in ['b1','b2','c1','c2']}
    h0,_=compose(variants['E'],d/'rules');variants['H0']=h0
    _,variants['D']=compose(a.load(d/'rules/baseline.jsonl'),d/'rules')
    policies=POLICIES if args.split=='dev' else list(dict.fromkeys(['G0','G1',json.loads((OUT/'FREEZE.json').read_text())['selected_policy']]))
    for pol in policies:variants[pol]=gated(h0,pol,rules,stab)
    rows=[];scores={name:{i:int(correct(g,p[i])) for i,g in gold.items()} for name,p in variants.items()}
    for name,p in variants.items():
        for task in a.TASKS:
            ids=[i for i,g in gold.items() if g['task_name']==task]
            rows.append({'variant':name,'task':task,'n':len(ids),'correct':sum(scores[name][i] for i in ids),
                'accuracy':np.mean([scores[name][i] for i in ids]),'none':sum(p[i].get('answer_parsed')=='none' for i in ids),
                'numeric':sum(numeric(p[i].get('answer_parsed')) for i in ids),'parse_errors':sum(bool(p[i].get('parse_error')) for i in ids)})
        a.jsonlwrite(d/f'predictions_{name}.jsonl',p.values())
    a.csvwrite(d/'task_metrics.csv',rows)
    pointids=sorted({base_id(g) for g in gold.values()})
    selection=json.loads((OUT/'selection.json').read_text())['selected'][args.split]
    cells=defaultdict(list)
    for row in selection:cells[tuple(row['stratum'])].append('_'.join(row['key']))
    folds={};offset=0
    for cell,ids in sorted(cells.items()):
        for j,pid in enumerate(ids):folds[pid]=(j+offset)%3
        offset+=len(ids)
    actions=[];policyrows=[]
    for pol in policies:
        net_by_task=Counter();foldnet=Counter();harm=helped=changed=0;points=set()
        for i,g in gold.items():
            if g['task_name'] not in ['B2_seasonality_amp','C2_step_mag']:
                assert variants[pol][i].get('answer_parsed')==h0[i].get('answer_parsed');continue
            before=scores['H0'][i];after=scores[pol][i];delta=after-before
            net_by_task[g['task_name']]+=delta;foldnet[folds[base_id(g)]]+=delta
            if variants[pol][i].get('answer_parsed')!=h0[i].get('answer_parsed'):
                changed+=1;points.add(base_id(g));harm+=int(delta<0);helped+=int(delta>0)
                upstream_task='B1_seasonality_present' if g['task_name']=='B2_seasonality_amp' else 'C1_step_time'
                uid=base_id(g)+'_'+upstream_task
                actions.append({'policy':pol,'id':i,'task':g['task_name'],'before':h0[i]['answer_parsed'],
                    'after':variants[pol][i]['answer_parsed'],'gold':g['answer'],'before_correct':before,'after_correct':after,
                    'upstream_answer':h0[uid]['answer_parsed'],'c1_rule_veto':bool(rules['c1'].get(base_id(g)+'_C1_step_time',{}).get('use_alt')),
                    'stability':stab.get(i,{}).get('S')})
        policyrows.append({'policy':pol,'changed':changed,'affected_points':len(points),'helped':helped,'harmed':harm,'net':helped-harm,
            'B2_net':net_by_task['B2_seasonality_amp'],'C2_net':net_by_task['C2_step_mag'],**{f'fold{f}_net':foldnet[f] for f in range(3)}})
    a.csvwrite(d/'gate_policy_metrics.csv',policyrows);a.csvwrite(d/'gate_actions.csv',actions)
    a.dump(d/'fold_assignments.json',folds)
    if args.split=='dev':
        old=next(r for r in policyrows if r['policy']=='G1')
        eligible=[r for r in policyrows if r['policy'] not in ['G0','G1'] and r['net']>=2 and min(r['B2_net'],r['C2_net'])>=0
            and sum(r[f'fold{f}_net']>=0 for f in range(3))>=2 and min(r[f'fold{f}_net'] for f in range(3))>=-1 and r['harmed']<=old['harmed']]
        eligible.sort(key=lambda r:(-r['net'],r['harmed'],0 if r['policy']=='G2' else 1,-float(r['policy'].split('-')[1]) if '-' in r['policy'] else 0))
        chosen=eligible[0]['policy'] if eligible else 'G0'
        scriptnames=['analyze_gate_20261003.py','prepare_gate_20261003.py','run_gate_vertex_20261003.py',
            'revision_matched_protocol_20261002.py','render_prompt_routeA_a3.py','score.py','revise_results_20261001.py',
            'predict_b1_from_series.py','predict_b2_from_series.py','predict_c1_none_guard_from_series.py','predict_c2_from_routeA_a3_prompt.py',
            'apply_gate_v3_consistency.py','run_baseline_v3.py','step_residual_detector_v3_2.py','egms_autolabel_trend_qa_v5_8.py']
        snapshot=OUT/'code_snapshot';snapshot.mkdir(exist_ok=True)
        for name in scriptnames:shutil.copy2(ROOT/'scripts'/name,snapshot/name)
        freeze={'selected_policy':chosen,'selection_reason':'preregistered finite development selection; G0 fallback when no eligible active policy',
            'policies':policyrows,'eligible':[r['policy'] for r in eligible],
            'code_sha256':{name:a.sha(ROOT/'scripts'/name) for name in scriptnames},
            'selection_sha256':a.sha(OUT/'selection.json'),'validation_requests_sha256':a.sha(OUT/'validation/requests_frozen.jsonl'),
            'validation_predictions_seen':False,'model':'gemini-3.8-flash','thinking_level':'MEDIUM',
            'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'generation_config':{'thinkingConfig':{'thinkingLevel':'MEDIUM'},'maxOutputTokens':2048,'responseMimeType':'application/json'}}
        assert not (OUT/'FREEZE.json').exists(),'Do not overwrite a freeze'
        a.dump(OUT/'FREEZE.json',freeze)
        print('FROZEN',chosen,json.dumps(policyrows),flush=True)
    else:
        chosen=json.loads((OUT/'FREEZE.json').read_text())['selected_policy']
        rng=np.random.default_rng(20261003); comparisons=[]
        for left,right in [(chosen,'H0'),(chosen,'G1'),(chosen,'D'),('H0','E'),('E','R')]:
            selected_tasks=['B2_seasonality_amp','C2_step_mag'] if (left,right)==(chosen,'H0') else a.TASKS
            delta={p:np.mean([scores[left][i]-scores[right][i] for i,g in gold.items() if base_id(g)==p and g['task_name'] in selected_tasks]) for p in pointids}
            draws=np.zeros(10000)
            for ids in cells.values():
                values=np.array([delta[p] for p in ids]);draws+=rng.choice(values,size=(10000,len(ids)),replace=True).sum(axis=1)
            draws/=len(pointids)
            comparisons.append({'left':left,'right':right,'tasks':selected_tasks,'delta':np.mean(list(delta.values())),
                'ci95':np.quantile(draws,[.025,.975]).tolist(),'unit':'point / unique 1km block','bootstrap':10000})
        a.dump(d/'paired_comparisons.json',comparisons)
        print('VALIDATION',json.dumps(comparisons),flush=True)

if __name__=='__main__':main()
