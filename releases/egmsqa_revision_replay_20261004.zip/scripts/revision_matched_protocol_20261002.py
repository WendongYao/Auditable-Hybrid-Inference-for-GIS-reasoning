"""Frozen prompt construction and deterministic pipeline for matched revision runs."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from revision_window_audit_20261002 import records, fingerprint, ROOT
from prepare_revision_matched_subset_20261002 import OUT
from render_prompt_routeA_a3 import render_prompt_routeA_a3
import revise_results_20261001 as a

DEFINITIONS={
'A1_trend_dir':'Fit ordinary least squares displacement against elapsed years (365.25 days/year), with an intercept. If slope >= 0.2 mm/year output uplifting; if <= -0.2 output subsiding; otherwise stable.',
'A2_trend_v':'Fit ordinary least squares displacement against elapsed years (365.25 days/year), with an intercept. Output slope in mm/year rounded to one decimal.',
'B1_seasonality_present':'Fit displacement = a*sin(2*pi*t)+b*cos(2*pi*t)+c, t in years (365.25 days), without a linear trend term. Annual amplitude is sqrt(a*a+b*b). Output seasonal if amplitude >= 0.5 mm, otherwise nonseasonal.',
'B2_seasonality_amp':'Fit displacement = a*sin(2*pi*t)+b*cos(2*pi*t)+c, t in years (365.25 days), without a linear trend term. Annual amplitude is sqrt(a*a+b*b). If amplitude >= 0.5 mm output it rounded to one decimal, otherwise none.',
'C1_step_time':'The operational step label is the largest absolute displacement difference between adjacent finite observations in the original date grid. A pair containing a missing value is invalid. If its absolute jump is >= max(0.5 mm, 3*rmse_mm), output the date of its right-hand observation as yyyymmdd; otherwise none. Resolve ties using the earliest pair. Persistence is not a condition of this operational label.',
'C2_step_mag':'The operational step label is the largest absolute displacement difference between adjacent finite observations in the original date grid. A pair containing a missing value is invalid. If its absolute jump is >= max(0.5 mm, 3*rmse_mm), output the SIGNED right-minus-left jump in mm rounded to one decimal; otherwise none. Resolve ties using the earliest pair. Persistence is not a condition of this operational label.'}

def make_prompt(x, evidence):
    s=x['context']['series']; task=x['task_name']
    header='Analyze only the supplied observations. Return exactly one JSON object with a single key "answer". No explanation. The answer must be a number or the specified string.\nTASK: '+task+'\nDEFINITION: '+DEFINITIONS[task]+'\n'
    obs='QUALITY_METADATA\n'+json.dumps(x['context']['static'],sort_keys=True)+'\nOBSERVATIONS (date, displacement_mm; null means missing)\n'
    obs+='\n'.join(f'{t}, {json.dumps(v)}' for t,v in zip(s['t_iso'],s['d_mm']))+'\n'
    if evidence:
        generated=render_prompt_routeA_a3(x,global_mode='summary',c2_semantics='signed_delta')
        # Retain only observation-derived evidence; discard historical decision instructions.
        marker='QUESTION: '+x['question']+'\n\n'
        assert marker in generated
        obs+='\nCOMPUTED SUPPORTING EVIDENCE (the task definition above takes precedence)\n'+generated.split(marker,1)[1]
    return header+obs

def freeze_requests(dataset,out):
    requests=[]
    for x in dataset:
        for branch in ['raw','evidence']:
            p=make_prompt(x,branch=='evidence')
            requests.append({'request_key':branch+'|'+x['id'],'id':x['id'],'task_name':x['task_name'],'branch':branch,'prompt':p,
                             'prompt_sha256':hashlib.sha256(p.encode()).hexdigest(),'input_series_sha256':fingerprint(x['context']['series'])})
    a.jsonlwrite(out,requests)
    return requests

def local_pipeline(dataset_path,out):
    out.mkdir(parents=True,exist_ok=True)
    jobs=[('baseline','run_baseline_v3.py',['--dataset',str(dataset_path),'--v_stable','.2','--step_detector_module','step_residual_detector_v3_2']),
          ('b1','predict_b1_from_series.py',['--ids_jsonl',str(dataset_path),'--dataset',str(dataset_path),'--amp_mode','sin','--sin_period_days','365.25','--amp_thr','.9','--snr_thr','1.2','--noise_mode','rmse','--dump_debug']),
          ('b2','predict_b2_from_series.py',['--ids_jsonl',str(dataset_path),'--dataset',str(dataset_path),'--amp_thr','1','--snr_thr','1.2','--amp_mode','sin','--sin_period_days','365.25','--noise_mode','rmse','--round_to','.25','--dump_debug']),
          ('c1','predict_c1_none_guard_from_series.py',['--ids_jsonl',str(dataset_path),'--dataset',str(dataset_path),'--none_mag_max','1.2','--none_snr_max','2.5','--none_pf_max','.75','--none_edge_max','2','--none_score_max','1.5','--dump_debug'])]
    for name,script,args in jobs:
        with (out/f'{name}.log').open('w',encoding='utf8') as f:
            subprocess.run([sys.executable,str(ROOT/'scripts'/script),*args,'--out',str(out/f'{name}.jsonl')],stdout=f,stderr=subprocess.STDOUT,check=True)
    # Use original renderer's structured candidate format for the same frozen C2 rule.
    prompts=[{'id':x['id'],'prompt':render_prompt_routeA_a3(x,c2_semantics='signed_delta')} for x in records(dataset_path)]
    a.jsonlwrite(out/'rule_prompts.jsonl',prompts)
    args=['--ids_jsonl',str(dataset_path),'--routeA_prompts_jsonl',str(out/'rule_prompts.jsonl'),'--out',str(out/'c2.jsonl'),
          '--use_abs_delta','--mag_thr','2.7','--snr_thr','2.2','--persist_frac_thr','.8','--min_post_points','5','--support_gap_max','.8',
          '--persist_frac_soft_min','.55','--pf_override_snr_margin','.5','--pf_override_mag_margin','.5','--output_semantics','signed_delta','--dump_debug']
    with (out/'c2.log').open('w',encoding='utf8') as f:
        subprocess.run([sys.executable,str(ROOT/'scripts/predict_c2_from_routeA_a3_prompt.py'),*args],stdout=f,stderr=subprocess.STDOUT,check=True)

def compose(base,rule_dir):
    pred={i:dict(p) for i,p in base.items()}
    for name in ['b1','b2','c1','c2']:
        for p in records(rule_dir/f'{name}.jsonl'):
            if p['task_name'] != {'b1':'B1_seasonality_present','b2':'B2_seasonality_amp','c1':'C1_step_time','c2':'C2_step_mag'}[name]:continue
            if name!='c1' or p.get('use_alt'):pred[p['id']]=p
    assert all(pred[i]['answer_parsed']==p['answer_parsed'] for i,p in base.items() if p['task_name'].startswith('A'))
    return pred,a.apply_gate(pred)

def main():
    dataset=list(records(OUT/'dataset_fullprefix.jsonl'))
    req=freeze_requests(dataset,OUT/'requests_frozen.jsonl')
    # Gold and metadata other than observed static fields cannot affect prompts.
    for x in dataset:
        altered={**x,'answer':'sentinel','bucket_label':'sentinel','answer_numeric':999999,'meta':{}}
        assert make_prompt(x,True)==make_prompt(altered,True)
        assert make_prompt(x,False)==make_prompt(altered,False)
    local_pipeline(OUT/'dataset_fullprefix.jsonl',OUT/'rules')
    base=a.load(OUT/'rules/baseline.jsonl',True)
    rules,full=compose(base,OUT/'rules')
    a.jsonlwrite(OUT/'deterministic_rules.jsonl',rules.values());a.jsonlwrite(OUT/'deterministic_full.jsonl',full.values())
    a.dump(OUT/'frozen_manifest.json',{'dataset_sha256':a.sha(OUT/'dataset_fullprefix.jsonl'),'requests_sha256':a.sha(OUT/'requests_frozen.jsonl'),
        'protocol_script_sha256':a.sha(Path(__file__)),'requests':len(req),'gold_mutation_prompt_invariance':True,
        'model':'gpt-5.2-2025-12-11','reasoning':'none','temperature':0,'max_output_tokens':128,'budget_usd':25})
    print('Frozen requests:',len(req),'local pipeline complete')

if __name__=='__main__':main()
